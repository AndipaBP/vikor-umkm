<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Umkm_penilaian extends Model
{
    use HasFactory;

    protected $table = "umkm_penilaian";

    public function umkm(){

        return $this->belongsTo(Umkm::class);
    }

    public function kriteria(){

        return $this->belongsTo(Kriteria::class);
    }

    public function sub_kriteria(){

        return $this->belongsTo(Sub_kriteria::class);
    }


}
