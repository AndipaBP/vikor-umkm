<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Umkm extends Model
{
    use HasFactory;

    protected $table = "umkm";

    public function user(){

        return $this->belongsTo(User::class);
    }

    public function bidang_usaha(){

        return $this->belongsTo(Bidang_usaha::class);
    }

    public function penilaian(){

        return $this->hasMany(Umkm_penilaian::class);
    }

    public function perangkingan(){

        return $this->hasMany(Perankingan::class);
    }

    

}
