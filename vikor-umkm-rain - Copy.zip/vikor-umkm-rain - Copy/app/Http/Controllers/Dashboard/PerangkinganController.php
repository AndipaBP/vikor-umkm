<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Umkm;
use App\Models\Umkm_penilaian;
use App\Models\Bidang_usaha;
use App\Models\Kriteria;
use App\Models\Sub_kriteria;
use App\Models\User;
use App\Models\Perangkingan;
use PDF;


class PerangkinganController extends Controller
{
    //
    public function bidang_usaha(){

        $bidang_usaha = Bidang_usaha::OrderBy('nama','asc')->get();

        return view('dashboard.perangkingan.daftar_bidang', ['bidang_usaha'=>$bidang_usaha]);
    }

    public function index($id){

        // dd($id);

        $v=array('0.45','0.5','0.55');
        $umkm = $this->matriks_perangkingan($id, $v[1]);
        $bidang_usaha = Bidang_usaha::find($id)->nama;
        
        return view('dashboard.perangkingan.index', ['bidang_usaha' => $bidang_usaha, 'umkm'=> $umkm]);
    }

    public function matriks_perangkingan($bidang_usaha, $v){

        // dd($sQ);
        $umkm = Umkm::join('perangkingan','perangkingan.umkm_id','umkm.id')
                    ->OrderBy('perangkingan.nilai','asc')
                    ->where('umkm.bidang_usaha_id', $bidang_usaha)
                    ->where('perangkingan.nilai_v',$v)
                    ->select('umkm.nama_usaha','umkm.nama','umkm.alamat_usaha','perangkingan.*')
                    ->get();

        return $umkm;
    }

    public function cetak_laporan($id){
        $v=array('0.45','0.5','0.55');


        $umkm = $this->matriks_perangkingan($id, $v[1]);

        
        $bidang_usaha = Bidang_usaha::find($id)->nama;

        $pdf = PDF::loadView('dashboard.perangkingan.cetak', ['umkm' => $umkm,'bidang_usaha'=>$bidang_usaha]);
        return $pdf->stream();

    }
}
