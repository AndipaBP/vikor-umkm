<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Umkm;
use App\Models\Umkm_penilaian;
use App\Models\Bidang_usaha;
use App\Models\Kriteria;
use App\Models\Sub_kriteria;
use App\Models\User;


class UmkmController extends Controller
{
    //
    public function daftar_bidang_usaha(){

        $bidang_usaha = Bidang_usaha::OrderBy('nama','asc')->get();
        
        return view('dashboard.umkm.daftar_bidang',['bidang_usaha'=>$bidang_usaha]);
    }
    public function index($id){

        if ($id == 'semua') {

            $umkm = Umkm::OrderBy('bidang_usaha_id','asc')->get();
            $bidang_usaha = 'Semua';

        } else {

            $umkm = Umkm::where('bidang_usaha_id', $id)->get();
            $bidang_usaha = Bidang_usaha::find($id)->nama;

        }
        
        return view('dashboard.umkm.index',['umkm'=>$umkm, 'bidang_usaha'=>$bidang_usaha]);
    }

    public function tambah(){

        $bidang_usaha = Bidang_usaha::OrderBy('nama','asc')->get();

        return view('dashboard.umkm.tambah',['bidang_usaha' => $bidang_usaha]);
    }

    public function simpan(Request $request){

        // dd($request->all());

        $this->validate($request, [
            'nik' => 'required|max:155',
            'nama_pemilik' => 'required',
            'jenis_kelamin' => 'required',
            'no_telepon' => 'required',
            'email' => 'required',
            'nama_usaha' => 'required',
            'tahun_berdiri' => 'required',
            'bidang_usaha' => 'required',
            'alamat_usaha' => 'required'
        ]);

        $new_user = new User;
        $new_user->username = $request->nik;
        $new_user->email = $request->email;
        $new_user->password = bcrypt($request->nik);
        $new_user->roles_id = 2;
        $new_user->status_id = 1;
        $new_user->save();

        $user = User::where('username', $request->nik)->where('roles_id', 2)->first();

        $new_umkm = new Umkm;
        $new_umkm->user_id = $user->id;
        $new_umkm->nama = $request->nama_pemilik;
        $new_umkm->no_telepon = $request->no_telepon;
        $new_umkm->jenis_kelamin = $request->jenis_kelamin;
        $new_umkm->nama_usaha = $request->nama_usaha;
        $new_umkm->tahun_berdiri = $request->tahun_berdiri;
        $new_umkm->alamat_usaha = $request->alamat_usaha;
        $new_umkm->bidang_usaha_id = $request->bidang_usaha;
        $new_umkm->save();

        
        $notification['title-message'] = 'Berhasil';
        $notification['message'] = 'UMKM Ditambahkan';
        $notification['type-alert'] = 'success';

        $data = array(
            'judul-notifikasi' => $notification['title-message'],
            'pesan-notifikasi' => $notification['message'],
            'tipe-notifikasi'=> $notification['type-alert']
        );
    
        return redirect('/umkm')->with($data);
    }

    public function detail_umkm($id){


        $umkm = Umkm::find($id);


        return view('dashboard.umkm.detail', ['umkm'=>$umkm]);
    }

    public function ubah_umkm($id){

        $umkm = Umkm::find($id);

        $bidang_usaha = Bidang_usaha::OrderBy('nama','asc')->get();

        return view('dashboard.umkm.ubah', ['umkm'=>$umkm , 'bidang_usaha' => $bidang_usaha]);

    }

    public function simpan_ubah_umkm($id, Request $request){


        // dd($request->all());

        $this->validate($request, [
            'nik' => 'required|max:155',
            'nama_pemilik' => 'required',
            'jenis_kelamin' => 'required',
            'no_telepon' => 'required',
            'email' => 'required',
            'nama_usaha' => 'required',
            'tahun_berdiri' => 'required',
            'bidang_usaha' => 'required',
            'alamat_usaha' => 'required'
        ]);

   

        $user = User::where('username', $request->nik)->where('roles_id', 2)->first();

        $umkm = Umkm::find($id);
        $umkm->nama = $request->nama_pemilik;
        $umkm->no_telepon = $request->no_telepon;
        $umkm->jenis_kelamin = $request->jenis_kelamin;
        $umkm->nama_usaha = $request->nama_usaha;
        $umkm->tahun_berdiri = $request->tahun_berdiri;
        $umkm->alamat_usaha = $request->alamat_usaha;
        $umkm->bidang_usaha_id = $request->bidang_usaha;

        $user = User::find($umkm->user_id);
        $user->username = $request->nik;
        $user->email = $request->email;

        if (isset($request->password)) {
            $user->password = bcrypt($request->password);

        }
        $user->save();
        $umkm->save();

        $notification['title-message'] = 'Berhasil';
        $notification['message'] = 'UMKM Diubah';
        $notification['type-alert'] = 'success';

        $data = array(
            'judul-notifikasi' => $notification['title-message'],
            'pesan-notifikasi' => $notification['message'],
            'tipe-notifikasi'=> $notification['type-alert']
        );


        return back()->with($data);

    }

    public function tambah_penilaian($id){

        $umkm = Umkm::find($id);

        $kriteria = Kriteria::all();

        return view('dashboard.umkm_penilaian.tambah', ['umkm' => $umkm, 'kriteria' => $kriteria]);
    }

    public function simpan_penilaian($id, Request $request){

        // dd($request->all());

        $kriteria = Kriteria::all();

        foreach ($kriteria as $row){

            $penilaian = new Umkm_penilaian;
            $penilaian->umkm_id = $id;
            $penilaian->kriteria_id = $row->id;
            $penilaian->sub_kriteria_id = $request->get('kriteria-'.$row->id);
            $get_nilai_sub_kriteria = Sub_kriteria::find($request->get('kriteria-'.$row->id));
            $penilaian->nilai = $get_nilai_sub_kriteria->nilai;
            $penilaian->save();
        }

        $notification['title-message'] = 'Berhasil';
        $notification['message'] = 'Penilaian UMKM Ditambahkan';
        $notification['type-alert'] = 'success';

        $data = array(
            'judul-notifikasi' => $notification['title-message'],
            'pesan-notifikasi' => $notification['message'],
            'tipe-notifikasi'=> $notification['type-alert']
        );

        return redirect('/umkm')->with($data);
    }

    public function ubah_penilaian($id){


        $umkm = Umkm::find($id);

        $array_kriteria = array();

        $umkm_penilaian = Umkm_penilaian::where('umkm_id', $id)->get();

        $i = 0;
        foreach ($umkm_penilaian as $row) {

            $kriteria = Kriteria::find($row->kriteria_id);
            $array_kriteria[$i]['penilaian_id'] = $row->id;
            $array_kriteria[$i]['id'] = $kriteria->id;
            $array_kriteria[$i]['nama'] = $kriteria->nama;
        


            $j = 0;

            foreach ($kriteria->sub_kriteria as $sub_kriteria) {
                $array_kriteria[$i]['sub_kriteria'][$j]['id'] = $sub_kriteria->id;
                $array_kriteria[$i]['sub_kriteria'][$j]['pilihan'] = $sub_kriteria->nama;
                $array_kriteria[$i]['sub_kriteria'][$j]['nilai'] = $sub_kriteria->nilai;
                $array_kriteria[$i]['sub_kriteria'][$j]['value'] = '';

                $cek_penilaian_siswa = Umkm_penilaian::where('umkm_id', $id)->where('sub_kriteria_id', $sub_kriteria->id)->first();
                if (isset($cek_penilaian_siswa)) {
                    $array_kriteria[$i]['sub_kriteria'][$j]['value'] = 'selected';
                }

                $j++;
            }

            $i++;
        }

        return view('dashboard.umkm_penilaian.ubah', ['umkm' => $umkm, 'kriteria' => $array_kriteria]);

    }

    public function simpan_ubah_penilaian($id, Request $request){

        // dd($request->all());

        $umkm_penilaian = Umkm_penilaian::where('umkm_id', $id)->get();

        foreach ($umkm_penilaian as $row) {

            $penilaian = Umkm_penilaian::find($row->id);
            $penilaian->sub_kriteria_id = $request->get($row->id.'-kriteria-'.$row->kriteria_id);
            $get_nilai_sub_kriteria = Sub_kriteria::find($request->get($row->id.'-kriteria-'.$row->kriteria_id));
            $penilaian->nilai = $get_nilai_sub_kriteria->nilai;
        
            $penilaian->save();
        }

        $notification['title-message'] = 'Berhasil';
        $notification['message'] = 'Penilaian UMKM Diubah';
        $notification['type-alert'] = 'success';

        $data = array(
            'judul-notifikasi' => $notification['title-message'],
            'pesan-notifikasi' => $notification['message'],
            'tipe-notifikasi'=> $notification['type-alert']
        );

        return back()->with($data);

    }

    public function hapus_umkm($id){

       $umkm = Umkm::find($id);

       User::where('id', $umkm->user_id)->delete();
       
       Umkm_penilaian::where('umkm_id', $id)->delete();

       $umkm->delete();

       $notification['title-message'] = 'Berhasil';
       $notification['message'] = 'UMKM Dihapus';
       $notification['type-alert'] = 'success';

       $data = array(
           'judul-notifikasi' => $notification['title-message'],
           'pesan-notifikasi' => $notification['message'],
           'tipe-notifikasi'=> $notification['type-alert']
       );

       return back()->with($data);
    }
}
