<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Umkm;
use App\Models\Umkm_penilaian;
use App\Models\Bidang_usaha;
use App\Models\Kriteria;
use App\Models\Sub_kriteria;
use App\Models\User;
use Auth;

class UserController extends Controller
{
    //

    public function simpan_ubah(Request $request){

        $this->validate($request, [
            'nik' => 'required|max:155',
            'nama_pemilik' => 'required',
            'jenis_kelamin' => 'required',
            'no_telepon' => 'required',
            'email' => 'required',
            'nama_usaha' => 'required',
            'tahun_berdiri' => 'required',
            'bidang_usaha' => 'required',
            'alamat_usaha' => 'required'
        ]);

   

        $umkm = Umkm::find(Auth::user()->umkm->id);
        $umkm->nama = $request->nama_pemilik;
        $umkm->no_telepon = $request->no_telepon;
        $umkm->jenis_kelamin = $request->jenis_kelamin;
        $umkm->nama_usaha = $request->nama_usaha;
        $umkm->tahun_berdiri = $request->tahun_berdiri;
        $umkm->alamat_usaha = $request->alamat_usaha;
        $umkm->bidang_usaha_id = $request->bidang_usaha;

        $user = User::find(Auth::user()->id);
        $user->username = $request->nik;
        $user->email = $request->email;
        $user->save();
        $umkm->save();

        
        $notification['title-message'] = 'Berhasil';
        $notification['message'] = 'Data Diubah';
        $notification['type-alert'] = 'success';

        $data = array(
            'judul-notifikasi' => $notification['title-message'],
            'pesan-notifikasi' => $notification['message'],
            'tipe-notifikasi'=> $notification['type-alert']
        );


        return back()->with($data);
    }

    public function penilaian(){

        $umkm = Umkm::find(Auth::user()->umkm->id);

        if ($umkm->penilaian->count() > 0) {

            $array_kriteria = array();

            $umkm_penilaian = Umkm_penilaian::where('umkm_id', Auth::user()->umkm->id)->get();
    
            $i = 0;
            foreach ($umkm_penilaian as $row) {
    
                $kriteria = Kriteria::find($row->kriteria_id);
                $array_kriteria[$i]['penilaian_id'] = $row->id;
                $array_kriteria[$i]['id'] = $kriteria->id;
                $array_kriteria[$i]['nama'] = $kriteria->nama;
            
    
    
                $j = 0;
    
                foreach ($kriteria->sub_kriteria as $sub_kriteria) {
                    $array_kriteria[$i]['sub_kriteria'][$j]['id'] = $sub_kriteria->id;
                    $array_kriteria[$i]['sub_kriteria'][$j]['pilihan'] = $sub_kriteria->nama;
                    $array_kriteria[$i]['sub_kriteria'][$j]['nilai'] = $sub_kriteria->nilai;
                    $array_kriteria[$i]['sub_kriteria'][$j]['value'] = '';
    
                    $cek_penilaian_siswa = Umkm_penilaian::where('umkm_id', Auth::user()->umkm->id)->where('sub_kriteria_id', $sub_kriteria->id)->first();
                    if (isset($cek_penilaian_siswa)) {
                        $array_kriteria[$i]['sub_kriteria'][$j]['value'] = 'selected';
                    }
    
                    $j++;
                }
    
                $i++;
            }
    
            return view('dashboard.user.ubah_penilaian', ['umkm' => $umkm, 'kriteria' => $array_kriteria]);
            
            
        }
        else{

            $kriteria = Kriteria::all();

            return view('dashboard.user.penilaian', ['umkm' => $umkm, 'kriteria' => $kriteria]);
        }

    }

    public function simpan_penilaian(Request $request){

        $kriteria = Kriteria::all();

        foreach ($kriteria as $row){

            $penilaian = new Umkm_penilaian;
            $penilaian->umkm_id = Auth::user()->umkm->id;
            $penilaian->kriteria_id = $row->id;
            $penilaian->sub_kriteria_id = $request->get('kriteria-'.$row->id);
            $get_nilai_sub_kriteria = Sub_kriteria::find($request->get('kriteria-'.$row->id));
            $penilaian->nilai = $get_nilai_sub_kriteria->nilai;
            $penilaian->save();
        }

         
        $notification['title-message'] = 'Berhasil';
        $notification['message'] = 'Detail UMKM Ditambahkan';
        $notification['type-alert'] = 'success';

        $data = array(
            'judul-notifikasi' => $notification['title-message'],
            'pesan-notifikasi' => $notification['message'],
            'tipe-notifikasi'=> $notification['type-alert']
        );

        return redirect('/')->with($data);

    }

    public function simpan_ubah_penilaian(Request $request){

        $umkm_penilaian = Umkm_penilaian::where('umkm_id', Auth::user()->umkm->id)->get();

        foreach ($umkm_penilaian as $row) {

            $penilaian = Umkm_penilaian::find($row->id);
            $penilaian->sub_kriteria_id = $request->get($row->id.'-kriteria-'.$row->kriteria_id);
            $get_nilai_sub_kriteria = Sub_kriteria::find($request->get($row->id.'-kriteria-'.$row->kriteria_id));
            $penilaian->nilai = $get_nilai_sub_kriteria->nilai;
        
            $penilaian->save();
        }

        $notification['title-message'] = 'Berhasil';
        $notification['message'] = 'Detail UMKM Diubah';
        $notification['type-alert'] = 'success';

        $data = array(
            'judul-notifikasi' => $notification['title-message'],
            'pesan-notifikasi' => $notification['message'],
            'tipe-notifikasi'=> $notification['type-alert']
        );

        return back()->with($data);
    }
}
