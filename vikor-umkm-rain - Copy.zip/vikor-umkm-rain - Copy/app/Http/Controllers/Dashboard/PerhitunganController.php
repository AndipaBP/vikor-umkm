<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Umkm;
use App\Models\Umkm_penilaian;
use App\Models\Bidang_usaha;
use App\Models\Kriteria;
use App\Models\Sub_kriteria;
use App\Models\User;
use App\Models\Perangkingan;


class PerhitunganController extends Controller
{
    //

    public function bidang_usaha(){

        $bidang_usaha = Bidang_usaha::OrderBy('nama','asc')->get();

        return view('dashboard.perhitungan.daftar_bidang', ['bidang_usaha'=>$bidang_usaha]);
    }

    public function index($id){

     
        try {

            $bidang_usaha = $id;
            $jumlah_kriteria = Kriteria::count();
            $bobot_kriteria = $this->bobot_kriteria();
            $this->hapus_perangkingan($bidang_usaha);
            $matriks_keputusan = $this->matriks_keputusan($bidang_usaha);
            $matriks_normalisasi =  $this->matriks_normalisasi($bidang_usaha, $matriks_keputusan);
            $matriks_normalisasi_terbobot = $this->matriks_normalisasi_terbobot($matriks_normalisasi, $bobot_kriteria);
            $utility_measure_s = $this->utility_measure_s($matriks_normalisasi_terbobot);
            $regret_measure_r = $this->regret_measure_r($matriks_normalisasi_terbobot);
    
            $v=array('0.45','0.5','0.55');
            $hitung_indeks_vikor = $this->hitung_indeks_vikor($utility_measure_s, $regret_measure_r, $v[1]);
            $perangkingan = $this->perangkingan($hitung_indeks_vikor, $v[1]);
    
            // dd($perangkingan);
            $this->simpan_perangkingan($perangkingan, $v[1]);
    
            $matriks_perangkingan = $this->matriks_perangkingan($bidang_usaha, $v[1]);
    
        } catch (\Throwable $th) {

            $notification['title-message'] = 'Gagal';
            $notification['message'] = 'Silahkan Periksa Kembali Data Yang Diinputkan';
            $notification['type-alert'] = 'danger';
    
            $data = array(
                'judul-notifikasi' => $notification['title-message'],
                'pesan-notifikasi' => $notification['message'],
                'tipe-notifikasi'=> $notification['type-alert']
            );

            return back()->with($data);
        }

        $bidang_usaha = Bidang_usaha::find($bidang_usaha)->nama;

        return view('dashboard.perhitungan.index', ['jumlah_kriteria'=> $jumlah_kriteria,'matriks_keputusan' => $matriks_keputusan, 'matriks_normalisasi' => $matriks_normalisasi, 'matriks_normalisasi_terbobot' => $matriks_normalisasi_terbobot, 'matriks_perangkingan' => $matriks_perangkingan, 'bidang_usaha'=>$bidang_usaha]);
    }


    public function bobot_kriteria(){


        $daftar_kriteria = Kriteria::all();
        $total_nilai_kriteria = Kriteria::sum('bobot');
        
        $bobot_kriteria = array();

        $i = 0;
        foreach($daftar_kriteria as $row){

            $bobot_kriteria[$row->id] = $row->bobot / $total_nilai_kriteria;
        }

        return $bobot_kriteria;
    }

    public function hapus_perangkingan($bidang_usaha){

        $umkm = Umkm::where('bidang_usaha_id', $bidang_usaha)
        ->get();

        foreach($umkm as $row){
            
            Perangkingan::where('umkm_id', $row->id)->delete();
        }
    }

    public function matriks_keputusan($bidang_usaha){

        $umkm = Umkm::where('bidang_usaha_id', $bidang_usaha)
        ->get();

        $matriks_keputusan = array();
        $i = 0;
        foreach ($umkm as $row) {

            // $matriks_keputusan[$i]['id'] = $row->id;
            // $matriks_keputusan[$i]['nama_usaha'] = $row->nama_usaha;

            // $j = 0;
            // foreach ($row->penilaian as $penilaian) {
            //     # code...
            //     $matriks_keputusan[$i]['penilaian'][$j] = $penilaian->nilai;
            //     $j++; 
            // }

    
            // $i++;
            if ($row->penilaian->count() > 0) {

                $matriks_keputusan[$row->id]['umkm_id'] = $row->id;

                $matriks_keputusan[$row->id]['nama_usaha'] = $row->nama_usaha;
    
                foreach($row->penilaian as $penilaian){
    
                    $matriks_keputusan[$row->id]['penilaian'][$penilaian->kriteria_id] = $penilaian->nilai;
                }
    
            }
         
            
        }

        // dd($matriks_keputusan);

        return $matriks_keputusan;
    }

    public function f_max_min($matriks_keputusan){

        // dd($matriks_keputusan);

        // $umkm = Umkm::where('umkm.bidang_usaha_id', $bidang_usaha)
        //             ->get();


        // $bidang = Bidang_usaha::where('id', 3)->get();
        // $umkm = Umkm::get();
        // $umkm_penilaian = array();
        // $i = 0;
        // foreach ($umkm as $row){
        //     $umkm_penilaian[$i]['nama'] = $row->nama;
        //     foreach ($bidang as $data){
        //         $umkm_penilaian[$i][$data->id]['max'] = Umkm_penilaian::select('nilai')->orderBy('nilai', 'desc')->first()->nilai;
        //         $umkm_penilaian[$i][$data->id]['min'] = Umkm_penilaian::select('nilai')->orderBy('nilai', 'asc')->first()->nilai;
        //     }
        //     $i++;

        // }
        // dd($umkm_penilaian);
        // dd($umkm);


   
        // $i = 0;
        // foreach ($umkm as $row) {

        //     foreach ($row->penilaian as $kriteria) {

        //         if(!isset($f_max_min[$kriteria->kriteria_id]['max'])) {
        //             $f_max_min[$kriteria->kriteria_id]['max'] =0;
        //             $f_max_min[$kriteria->kriteria_id]['min'] =9999999;
        //         }

        //         $nilai = $kriteria->nilai;

        //         $f_max_min[$kriteria->kriteria_id]['max'] = ($f_max_min[$kriteria->kriteria_id]['max'] < $nilai ? $nilai : $f_max_min[$kriteria->kriteria_id]['max']);
        //         $f_max_min[$kriteria->kriteria_id]['min'] = ($f_max_min[$kriteria->kriteria_id]['min'] > $nilai ? $nilai : $f_max_min[$kriteria->kriteria_id]['min']);
        //     }
        // }

        $f_max_min = array();

        foreach($matriks_keputusan as $row){

            foreach ($row['penilaian'] as $kriteria => $nilai) {

                if(!isset($f_max_min[$kriteria]['max'])) {
                    $f_max_min[$kriteria]['max'] =0;
                    $f_max_min[$kriteria]['min'] =9999999;
                }

                $nilai = $nilai;

                $f_max_min[$kriteria]['max'] = ($f_max_min[$kriteria]['max'] < $nilai ? $nilai : $f_max_min[$kriteria]['max']);
                $f_max_min[$kriteria]['min'] = ($f_max_min[$kriteria]['min'] > $nilai ? $nilai : $f_max_min[$kriteria]['min']);
            }
        }

        // dd($f_max_min);

        return $f_max_min;
    }

    public function matriks_normalisasi($bidang_usaha,$matriks_keputusan){


        $f_max_min = $this->f_max_min($matriks_keputusan);

        // dd($f_max_min);

        $matriks_normalisasi = array();

        // dd($matriks_keputusan);

        // foreach($matriks_keputusan as $row){

        //     // dd($row);
        //     $matriks_normalisasi[$row['umkm_id']]['umkm_id'] = $row['umkm_id'];
        //     $matriks_normalisasi[$row['umkm_id']]['nama_usaha'] = $row['nama_usaha'];

        //     foreach ($row['penilaian'] as $kriteria => $nilai) {

        //         $nilai = $nilai;
                
        //         # code...
        //     }
        // }

        $umkm = Umkm::where('umkm.bidang_usaha_id', $bidang_usaha)
                    ->get();
        
 
        foreach ($umkm as $row) {
            if ($row->penilaian->count() > 0) {
                $matriks_normalisasi[$row->id]['umkm_id'] = $row->id;
                $matriks_normalisasi[$row->id]['nama_usaha'] = $row->nama_usaha;

                foreach($row->penilaian as $penilaian){

                    $nilai = $penilaian->nilai;

                    // dd($nilai);
                    $matriks_keputusan[$row->id]['penilaian'][$penilaian->kriteria_id] = $penilaian->nilai;

                    if($penilaian->kriteria->tipe == 'benefit'){

                        $atas = ($f_max_min[$penilaian->kriteria_id]['max'] - $nilai);
                        $bawah = ($f_max_min[$penilaian->kriteria_id]['max'] - $f_max_min[$penilaian->kriteria_id]['min']);

                        
                        if($bawah == 0){

                            $hasil = 0;
                        }
                        else{
                            
                            $hasil = $atas / $bawah;

                            if ($hasil == (-0)) {
                                $hasil = 0;
                            }
    

                        }
                   
                        $matriks_normalisasi[$row->id]['nilai'][$penilaian->kriteria_id] = round($hasil ,3);

                    }
                    else{

                        $atas = ($f_max_min[$penilaian->kriteria_id]['min'] - $nilai);
                        $bawah = ($f_max_min[$penilaian->kriteria_id]['min'] - $f_max_min[$penilaian->kriteria_id]['max']);


                        if($bawah == 0){

                            $hasil = 0;
                        }
                        else{

                            $hasil = $atas / $bawah;

                            if ($hasil == (-0)) {
                                $hasil = 0;
                            }
                        }
                       

                        $matriks_normalisasi[$row->id]['nilai'][$penilaian->kriteria_id] = round($hasil ,3);

                    }

                }
            }

         


        //     $matriks_normalisasi[$i]['id'] = $row->id;
        //     $matriks_normalisasi[$i]['nama_usaha'] = $row->nama_usaha;

        //     // $j = 0;
        //     foreach ($row->penilaian as $penilaian) {

        //         $nilai = $penilaian->nilai;

        //         if($penilaian->kriteria->tipe == 'benefit'){

        //             $atas = ($f_max_min[$penilaian->kriteria_id]['max'] - $nilai);
        //             $bawah = ($f_max_min[$penilaian->kriteria_id]['max'] - $f_max_min[$penilaian->kriteria_id]['min']);
        //             $hasil = $atas / $bawah;

        //             if ($hasil == (-0)) {
        //                 $hasil = 0;
        //             }

        //             $matriks_normalisasi[$i]['nilai'][$penilaian->kriteria_id] = round($hasil ,3);

        //         }
        //         else{
        //             $atas = ($f_max_min[$penilaian->kriteria_id]['min'] - $nilai);
        //             $bawah = ($f_max_min[$penilaian->kriteria_id]['min'] - $f_max_min[$penilaian->kriteria_id]['max']);
        //             $hasil = $atas / $bawah;
        //             if ($hasil == (-0)) {
        //                 $hasil = 0;
        //             }

        //             $matriks_normalisasi[$i]['nilai'][$penilaian->kriteria_id] = round($hasil ,3);

        //         }

        //         // $j++;
        //     }


    
        }


        // dd($matriks_normalisasi);
        return $matriks_normalisasi;

    }

    public function matriks_normalisasi_terbobot($matriks_normalisasi, $bobot_kriteria){


        // dd($matriks_normalisasi);


        $matriks_normalisasi = $matriks_normalisasi;
        $bobot_kriteria = $bobot_kriteria;
        // dd($bobot_kriteria);
        $matriks_normalisasi_terbobot = array();

        foreach($matriks_normalisasi as $row){

            $matriks_normalisasi_terbobot[$row['umkm_id']]['umkm_id'] = $row['umkm_id'];
            $matriks_normalisasi_terbobot[$row['umkm_id']]['nama_usaha'] = $row['nama_usaha'];

            foreach ($row['nilai'] as $kriteria => $nilai) {

                $matriks_normalisasi_terbobot[$row['umkm_id']]['nilai'][$kriteria] = round($nilai * $bobot_kriteria[$kriteria], 2);
            }
        }

        // dd($matriks_normalisasi_terbobot);

        return $matriks_normalisasi_terbobot;
    }

    public function utility_measure_s($matriks_normalisasi_terbobot){

        // dd($matriks_normalisasi_terbobot);

        $matriks_normalisasi_terbobot = $matriks_normalisasi_terbobot;

        $S = array();

        
        foreach($matriks_normalisasi_terbobot as $row){
    
            $S[$row['umkm_id']] = 0;
            foreach ($row['nilai'] as $kriteria => $nilai) {

                $S[$row['umkm_id']] += $nilai;
            }
        }

        // dd($S);

        return $S;
    }

    public function regret_measure_r($matriks_normalisasi_terbobot){

        $matriks_normalisasi_terbobot = $matriks_normalisasi_terbobot;

        $R = array();

        
        foreach($matriks_normalisasi_terbobot as $row){
    
            $R[$row['umkm_id']] = 0;
            foreach ($row['nilai'] as $kriteria => $nilai) {

                $R[$row['umkm_id']] = ($R[$row['umkm_id']]<$nilai ? $nilai : $R[$row['umkm_id']]);
            }
        }

        // dd($R);

        return $R;
    }

    public function get_Q($utility_measure_s, $regret_measure_r, $v){
        // dd($utility_measure_s);

        $Q = array();

        $S = $utility_measure_s;
        $R = $regret_measure_r;

        $S_plus=max($utility_measure_s);
        $S_min=min($utility_measure_s);
        $R_plus=max($regret_measure_r);
        $R_min=min($regret_measure_r);

        // dd($R_min);

        foreach($regret_measure_r as $row=>$r){

            // dd($R_min[$row]);

            $Q[$row] = $v*(($S[$row]-$S_min)/($S_plus-$S_min))
            +(1-$v)*(($R[$row]-$R_min)/($R_plus-$R_min));;

        }


        // dd($Q);
        return $Q;

    }

    public function hitung_indeks_vikor($utility_measure_s, $regret_measure_r, $v){

        $Q = array();
        $Q[$v] = $this->get_Q($utility_measure_s, $regret_measure_r, $v);
        // dd($Q);
        return $Q;
    }

    public function get_sQ($Q, $v){

        $s_Q=array();

        foreach($Q as $i=>$v){
            $s_Q[]=array($i,$v);
            // $s_Q[$i]=$v;

        }
        // dd($s_Q);

        return $s_Q;

    }

    public function simpan_perangkingan($sQ, $v){

        // dd($sQ);
        foreach($sQ[$v] as $row=> $nilai){

            $perangkingan = new Perangkingan;
            $perangkingan->nilai_v = $v;
            $perangkingan->umkm_id = $nilai[0];
            $perangkingan->nilai = $nilai[1];
            $perangkingan->save();
        }

        // dd('selesai');

    }

    public function perangkingan($Q, $v){

        asort($Q[$v]);

        $sQ = array();
        $sQ[$v] = $this->get_SQ($Q[$v], $v);
        // dd($sQ);
        return $sQ;
    }

    public function matriks_perangkingan($bidang_usaha, $v){

        // dd($sQ);
        $umkm = Umkm::join('perangkingan','perangkingan.umkm_id','umkm.id')
                    ->OrderBy('perangkingan.nilai','asc')
                    ->where('umkm.bidang_usaha_id', $bidang_usaha)
                    ->where('perangkingan.nilai_v',$v)
                    ->select('umkm.nama_usaha','perangkingan.*')
                    ->get();

        return $umkm;
    }

    public function solusi_kompromi_kondisi_1($sQ, $bidang_usaha, $v){



        $m = Umkm::join('perangkingan','perangkingan.umkm_id','umkm.id')
                    ->where('umkm.bidang_usaha_id', $bidang_usaha)
                    ->count();

        $DQ = 1 / ($m - 1);

        $hasil = ($sQ[$v][1][1]-$sQ[$v][0][1]);

        if( $hasil >= $DQ ){
            $kondisi_1 = 'Terpenuhi';
        }
        else{

            $kondisi_1 = 'Tidak Terpenuhi';

        }

        return $kondisi_1;

    }

    public function solusi_kompromi_kondisi_2($sQ, $utility_measure_s, $regret_measure_r, $v_0, $v_2){

        //-- menghitung nilai Q untuk v=$V[0] (by vote)]
        $v_1 = "0.5";
        $Q[$v_0] = $this->get_Q($utility_measure_s, $regret_measure_r, $v_0);
        asort($Q[$v_0]);
        $sQ[$v_0] = $this->get_SQ($Q[$v_0], $v_0);
 
        //-- menghitung nilai Q untuk v=$V[2] (voting by majority rule)
        $Q[$v_2] = $this->get_Q($utility_measure_s, $regret_measure_r, $v_2);
        asort($Q[$v_2]);
        $sQ[$v_2] = $this->get_SQ($Q[$v_2], $v_2);

        // /-- pengecekan kondisi Acceptable Stability in Decision Making

        dd($sQ[$v_0][0][1]);
        
        if(($sQ[$v_1][0][1]==$sQ[$v_0][0][1]) && ($sQ[$v_1][0][1]==$sQ[$v_2][0][1])){
            $kondisi_2="Terpenuhi";
 
        }else{
            $kondisi_2="Tidak Terpenuhi";

        }




        // dd($kondisi_2);



    }


}
