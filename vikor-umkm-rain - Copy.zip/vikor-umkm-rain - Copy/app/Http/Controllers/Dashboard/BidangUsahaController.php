<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Bidang_usaha;
use App\Models\Umkm;


class BidangUsahaController extends Controller
{
    //

    public function index(){

        $bidang_usaha = Bidang_usaha::all();


        return view('dashboard.bidang_usaha.index', ['bidang_usaha' => $bidang_usaha]);
    }

    public function tambah_simpan(Request $request){

        $this->validate($request, [
            'nama_bidang_usaha' => 'required'
        ]);


        $bidang_usaha = new Bidang_usaha;
        $bidang_usaha->nama = $request->nama_bidang_usaha;
        $bidang_usaha->save();

        $notification['title-message'] = 'Berhasil';
        $notification['message'] = 'Bidang Usaha Ditambahkan';
        $notification['type-alert'] = 'success';

        $data = array(
            'judul-notifikasi' => $notification['title-message'],
            'pesan-notifikasi' => $notification['message'],
            'tipe-notifikasi'=> $notification['type-alert']
        );


        return back()->with($data);
    }

    public function ubah_simpan(Request $request){

        // dd($request->all());

        $this->validate($request, [
            'id_bidang_usaha' => 'required',
            'ubah_nama_bidang_usaha' => 'required'
        ]);

        $bidang_usaha = Bidang_usaha::find($request->id_bidang_usaha);
        $bidang_usaha->nama = $request->ubah_nama_bidang_usaha;
        $bidang_usaha->save();

        $notification['title-message'] = 'Berhasil';
        $notification['message'] = 'Bidang Usaha Diubah';
        $notification['type-alert'] = 'success';

        $data = array(
            'judul-notifikasi' => $notification['title-message'],
            'pesan-notifikasi' => $notification['message'],
            'tipe-notifikasi'=> $notification['type-alert']
        );


        return back()->with($data);
    }

    public function hapus($id){

        Bidang_usaha::find($id)->delete();

        Umkm::where('bidang_usaha_id', $id)->delete();

        $notification['title-message'] = 'Berhasil';
        $notification['message'] = 'Bidang Usaha Dihapus';
        $notification['type-alert'] = 'success';

        $data = array(
            'judul-notifikasi' => $notification['title-message'],
            'pesan-notifikasi' => $notification['message'],
            'tipe-notifikasi'=> $notification['type-alert']
        );

        return back()->with($data);
    }
}
