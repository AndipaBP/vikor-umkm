<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Umkm;
use App\Models\Umkm_penilaian;
use App\Models\Bidang_usaha;
use App\Models\Kriteria;
use App\Models\Sub_kriteria;
use App\Models\User;
use Auth;


class DashboardController extends Controller
{
    //

    public function index(){


        $roles = Auth::user()->roles_id;

        if ($roles == 1) {

            $bidang_usaha = Bidang_usaha::OrderBy('nama','asc')->get();

            return view('dashboard.index',['bidang_usaha'=>$bidang_usaha]);
        }
        else{


            $umkm = Umkm::find(Auth::user()->umkm->id); 

            $bidang_usaha = Bidang_usaha::OrderBy('nama','asc')->get();


            // dd($umkm);

            return view('dashboard.user.index', ['umkm' => $umkm, 'bidang_usaha' => $bidang_usaha]);
        }

    }

  
}
