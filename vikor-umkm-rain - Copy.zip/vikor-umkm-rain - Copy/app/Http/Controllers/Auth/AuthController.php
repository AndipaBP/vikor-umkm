<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Umkm;

use App\Models\Bidang_usaha;
use Auth;

class AuthController extends Controller
{
    //

    public function sign_in(){


        return view('auth.sign_in');
    }

    public function post_sign_in(Request $request){

        // dd($request->all());

        \Validator::make($request->all(),[
            "username" => "required",
            "password" => "required"
        ])->validate();

        if(Auth::attempt(['username' => $request->username, 'password' => $request->password])){

       
            return redirect('/');
        }
        else{

            $notification['title-message'] = 'Gagal';
            $notification['message'] = 'Username dan Password Salah';
            $notification['type-alert'] = 'danger';

            $data = array(
                'judul-notifikasi' => $notification['title-message'],
                'pesan-notifikasi' => $notification['message'],
                'tipe-notifikasi'=> $notification['type-alert']
            );

            return redirect('/sign-in')->with($data);
        }

    }

    public function sign_out(){

        Auth::logout();
        return redirect('/sign-in');
    }

    public function sign_up(){


        return view('auth.sign_up_1');
    }

    public function post_sign_up(Request $request){

        // dd($request->all());

        $validation = \Validator::make($request->all(),[
            "nik" => "required",
            "nama" => "required",
            "jenis_kelamin" => "required",
            "no_telepon" => "required"
        ])->validate();

        $cek_user = User::where('username', $request->nik)->first();

        if (isset($cek_user)) {

            $notification['title-message'] = 'Pemberitahuan';
            $notification['message'] = 'NIK Telah Terdaftar';
            $notification['type-alert'] = 'warning';
    
            $data = array(
                'judul-notifikasi' => $notification['title-message'],
                'pesan-notifikasi' => $notification['message'],
                'tipe-notifikasi'=> $notification['type-alert']
            );

            return back()->with($data);
    
        }

        $request->session()->put('sign_up_1', 'sudah');
        $request->session()->put('username', $request->nik);
        $request->session()->put('nama', $request->nama);
        $request->session()->put('jenis_kelamin', $request->jenis_kelamin);
        $request->session()->put('no_telepon', $request->no_telepon);

        

        return redirect('sign-up/langkah-kedua');

    }

    public function sign_up_2(Request $request){

        if ($request->session()->has('sign_up_1')) {

            $bidang_usaha = Bidang_usaha::OrderBy('nama','asc')->get();

            return view('auth.sign_up_2', ['bidang_usaha' => $bidang_usaha]);

        }
        else{

            return redirect('sign-up');
        }
    }

    public function post_sign_up_2(Request $request){

        // dd($request->all());

        $validation = \Validator::make($request->all(),[
            "nama_usaha" => "required",
            "tahun_berdiri" => "required",
            "bidang_usaha" => "required",
            "alamat_usaha" => "required",
        ])->validate();

        $request->session()->put('sign_up_2', 'sudah');
        $request->session()->put('nama_usaha', $request->nama_usaha);
        $request->session()->put('tahun_berdiri', $request->tahun_berdiri);
        $request->session()->put('bidang_usaha', $request->bidang_usaha);
        $request->session()->put('alamat_usaha', $request->alamat_usaha);
        

        return redirect('sign-up/langkah-ketiga');


    }

    public function sign_up_3(Request $request){

        if ($request->session()->has('sign_up_2')) {


            return view('auth.sign_up_3');

        }
        else{

            return redirect('sign-up');
        }

    }

    public function post_sign_up_3(Request $request){

        // dd($request->all());

        
        $validation = \Validator::make($request->all(),[
            "email" => "required",
            "password" => "required"
        ])->validate();

        $new_user = new User;
        $new_user->username = $request->session()->get('username');
        $new_user->email = $request->email;
        $new_user->password = bcrypt($request->password);
        $new_user->roles_id = 2;
        $new_user->status_id = 1;
        $new_user->save();

        
        $user = User::where('username', $request->session()->get('username'))->where('roles_id', 2)->first();

        $new_umkm = new Umkm;
        $new_umkm->user_id = $user->id;
        $new_umkm->nama = $request->session()->get('nama');
        $new_umkm->no_telepon = $request->session()->get('no_telepon');
        $new_umkm->jenis_kelamin = $request->session()->get('jenis_kelamin');
        $new_umkm->nama_usaha = $request->session()->get('nama_usaha');
        $new_umkm->tahun_berdiri = $request->session()->get('tahun_berdiri');
        $new_umkm->alamat_usaha = $request->session()->get('alamat_usaha');
        $new_umkm->bidang_usaha_id = $request->session()->get('bidang_usaha');
        $new_umkm->save();

        if(Auth::attempt(['username' => $request->session()->get('username'), 'password' => $request->password])){

       
            return redirect('/');
        }
        else{

            
            return redirect('/sign-in');
        }


    }

    public function change_password(Request $request){

        // dd($request->all());

        $validation = \Validator::make($request->all(),[
            'password_baru' => 'required',
        ])->validate();    

        $user = User::find(Auth::user()->id);
        $user->password = \Hash::make($request->get('password_baru'));
        $user->save();

        $notification['title-message'] = 'Berhasil';
        $notification['message'] = 'Password Telah Diubah';
        $notification['type-alert'] = 'success';

        $data = array(
            'judul-notifikasi' => $notification['title-message'],
            'pesan-notifikasi' => $notification['message'],
            'tipe-notifikasi'=> $notification['type-alert']
        );

        return back()->with($data);
    }
}
