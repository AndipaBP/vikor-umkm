
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign Up</title>

    <!-- Favicon icon -->
    <link rel="icon" href="{{asset('assets/images/favicon.ico')}}" type="image/x-icon">

    <!-- vendor css -->
    <link rel="stylesheet" href="{{asset('assets/css/style.css')}}">

</head>

<!-- [ auth-signin ] start -->
<div class="auth-wrapper">
	<div class="auth-content text-center">
		{{-- <img src="assets/images/logo.png" alt="" class="img-fluid mb-4"> --}}
        <h3>SPK UMKM</h3>
		<div class="card borderless">
			<div class="row align-items-center ">
				<div class="col-md-12">
					<div class="card-body">
						<h4 class="mb-3 f-w-400">Daftar </h4>
						<hr>
						<h5 class="mb-3 f-w-400">Data Usaha</h5>
                        <form action="{{route('sign_up_2')}}" method="post">
                            @csrf
                            <div class="form-group mb-3">
                                <input type="text" class="form-control" name="nama_usaha" id="nama_usaha" placeholder="Nama Usaha">
                            </div>
                            <div class="form-group mb-3">
                                <input type="number" class="form-control" name="tahun_berdiri" id="tahun_berdiri" placeholder="Tahun Berdiri">
                            </div>
                            <div class="form-group mb-4">
                                <select class="form-control" name="bidang_usaha" id="bidang_usaha" required>
                                    <option value="" disabled selected>--- Pilih Bidang Usaha ---</option>
                                    @foreach ($bidang_usaha as $row)
                                    <option value="{{$row->id}}">{{$row->nama}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group mb-3">
                                <input type="text" class="form-control" id="alamat_usaha" name="alamat_usaha" placeholder="Alamat Usaha" required>
                            </div>
                            <button class="btn btn-block btn-primary mb-4">Daftar</button>

                        </form>
						
						<hr>
                        <p class="mb-0 text-muted"> <a href="{{url('/sign-up')}}" class="f-w-400">Kembali</a></p>

					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- [ auth-signin ] end -->

<!-- Required Js -->
<script src="{{asset('assets/js/vendor-all.min.js')}}"></script>
<script src="{{asset('assets/js/plugins/bootstrap.min.js')}}"></script>
<script src="{{asset('assets/js/pcoded.min.js')}}"></script>

</body>

</html>
