@extends('dashboard.layout.main')

@section('title-page')
Perhitungan | Bidang Usaha
@endsection

@section('header-script')

@endsection

@section('page-header')
Perhitungan | Bidang Usaha
@endsection

@section('page-navigation')
<li class="breadcrumb-item">Perhitungan</li>
<li class="breadcrumb-item">Bidang Usaha</li>
@endsection

@section('content')
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">DAFTAR BIDANG USAHA</h5>
         
        </div>
        <div class="card-body table-border-style">
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th width="1%">No.</th>
                            <th>Bidang Usaha</th>
                            <th>Jumlah UMKM</th>
                            <th width="12%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
          
                        @foreach ($bidang_usaha as $row)
                        <tr>
                            <td>{{$loop->iteration}}.</td>
                            <td>{{$row->nama}}</td>
                            <td>{{$row->umkm()->count()}}</td>
                            <td><a href="{{url('/perhitungan/bidang-usaha')}}/{{$row->id}}" class="btn btn-sm btn-success"><i class="feather icon-bar-chart"></i> Mulai Perhitungan</a></td>
                        </tr>
                            
                        @endforeach
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection

@section('modal')

@endsection

@section('footer-script')

@endsection