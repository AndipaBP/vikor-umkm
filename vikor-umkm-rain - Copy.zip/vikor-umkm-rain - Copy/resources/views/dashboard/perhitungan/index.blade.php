@extends('dashboard.layout.main')

@section('title-page')
Perhitungan | Bidang Usaha | {{$bidang_usaha}}
@endsection

@section('header-script')

@endsection

@section('page-header')
Perhitungan | Bidang Usaha | {{$bidang_usaha}}
@endsection

@section('page-navigation')
<li class="breadcrumb-item">Perhitungan</li>
<li class="breadcrumb-item"><a href="{{url('/perhitungan')}}">Bidang Usaha</a></li>
<li class="breadcrumb-item">{{$bidang_usaha}}</li>
@endsection

@section('content')
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">MATRIKS KEPUTUSAN (F)</h5>
        </div>
        <div class="card-body table-border-style">
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead class="text-center" >
                        <tr>
                            <th style="vertical-align: middle;" rowspan="2">Nama Usaha</th>
                            <th colspan="{{$jumlah_kriteria}}">Kriteria</th>
                        </tr>
                        <tr>
                            @for ($i = 1; $i <= $jumlah_kriteria; $i++) 
                                <th>K{{$i}}</th>
                            @endfor
                        </tr>
                    </thead>
                    <tbody>
            
                       {{-- @for ($i = 0; $i < count($matriks_keputusan); $i++)    
                        <tr>
                            <td>{{$matriks_keputusan[$i]['nama_usaha']}}</td>
                            @for ($j = 0; $j < count($matriks_keputusan[$i]['penilaian']); $j++)
                                <td align="center">{{$matriks_keputusan[$i]['penilaian'][$j]}}</td>                                
                            @endfor
                        </tr>
                       @endfor --}}
                        
                       @foreach ($matriks_keputusan as $row)

                       <tr>
                            <td>{{$row['nama_usaha']}}</td>
                            @foreach ($row['penilaian'] as $kriteria => $nilai )
                            <td align="center">{{$nilai}}</td>
                            @endforeach
                       </tr>
                       @endforeach
                       
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">MATRIKS NORMALISASI (N)</h5>
        </div>
        <div class="card-body table-border-style">
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead class="text-center" >
                        <tr>
                            <th style="vertical-align: middle;" rowspan="2">Nama Usaha</th>
                            <th colspan="{{$jumlah_kriteria}}">Kriteria</th>
                        </tr>
                        <tr>
                            @for ($i = 1; $i <= $jumlah_kriteria; $i++) 
                                <th>K{{$i}}</th>
                            @endfor
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($matriks_normalisasi as $row)
                        <tr>
                            <td>{{$row['nama_usaha']}}</td>
                            @foreach ($row['nilai'] as $kriteria => $nilai )
                            <td align="center">{{$nilai}}</td>
                            @endforeach
                            
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">MATRIKS NORMALISASI TERBOBOT (F*)</h5>
        </div>
        <div class="card-body table-border-style">
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead class="text-center" >
                        <tr>
                            <th style="vertical-align: middle;" rowspan="2">Nama Usaha</th>
                            <th colspan="{{$jumlah_kriteria}}">Kriteria</th>
                        </tr>
                        <tr>
                            @for ($i = 1; $i <= $jumlah_kriteria; $i++) 
                                <th>K{{$i}}</th>
                            @endfor
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($matriks_normalisasi_terbobot as $row)
                        <tr>
                            <td>{{$row['nama_usaha']}}</td>
                            @foreach ($row['nilai'] as $kriteria => $nilai )
                            <td align="center">{{$nilai}}</td>
                            @endforeach
                            
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">PERANGKINGAN</h5>
        </div>
        <div class="card-body table-border-style">
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead class="text-center" >
                        <tr>
                            <th width="1%">Rangking</th>
                            <th style="vertical-align: middle;">Nama Usaha</th>
                            <th>Nilai</th>
                        </tr>
                       
                    </thead>
                    <tbody >
                        @foreach ($matriks_perangkingan as $row)
                        <tr>
                            <td class="text-center">{{$loop->iteration}}</td>
                            <td>{{$row->nama_usaha}}</td>
                            <td class="text-center">{{$row->nilai}}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection

@section('modal')

@endsection

@section('footer-script')

<script>



</script>

@endsection