@extends('dashboard.layout.main')

@section('title-page')
DASHBOARD
@endsection

@section('header-script')

@endsection

@section('page-header')
DASHBOARD
@endsection

@section('page-navigation')
    
@endsection

@section('content')
@foreach ($bidang_usaha as $row)
<div class="col-md-4 col-xl-4">
    <div class="card flat-card">
        <div class="row-table">
            <div class="col-sm-3 card-body">
                <i class="feather icon-filter"></i>
            </div>
            <div class="col-sm-9">
                <h4>{{$row->nama}}</h4>
                <h6>UMKM : {{$row->umkm()->count()}}</h6>
            </div>
        </div>
    </div>
</div>
@endforeach


@endsection

@section('modal')

@endsection

@section('footer-script')

@endsection