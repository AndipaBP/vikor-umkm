@extends('dashboard.layout.main')

@section('title-page')
UMKM | PENILAIAN
@endsection

@section('header-script')

@endsection

@section('page-header')
UMKM | PENILAIAN
@endsection

@section('page-navigation')
<li class="breadcrumb-item"><a href="{{url('/umkm')}}">UMKM</a> </li>
<li class="breadcrumb-item">PENILAIAN</li>
@endsection

@section('content')
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">PENILAIAN</h5>
            <div class="float-right">
                <h5>Nama Pemilik : {{$umkm->nama}} | Nama Usaha : {{$umkm->nama_usaha}}</h5>

            </div>
        </div>
        <div class="card-body table-border-style">
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th width="1%">No.</th>
                            <th>Kriteria</th>
                            <th>Nilai</th>
                        </tr>
                    </thead>
                    <form action="{{url()->current()}}/simpan" method="post">
                    @csrf
                        <tbody>
                        
                            @foreach ($kriteria as $row)
                            <tr>
                                <td>
                                    {{$loop->iteration}}
                                </td>
                                <td>
                                    {{$row->nama}}
                                </td>
                                <td>
                                    <div class="form-group">
                                        <select class="form-control" name="kriteria-{{$row->id}}" required>
                                            <option value="" selected disabled>--- Pilih ---</option>
                                            @foreach ($row->sub_kriteria as $j)
                                                <option value="{{$j->id}}">{{$j->nama}}</option>
                                            @endforeach
                                        </select>
                                </td>
                            </tr>
                                
                            @endforeach
                            
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="3">
                                    <div class="float-right">
                                        <button class="btn btn-success"><i class="feather icon-save"></i> Simpan</button>

                                    </div>
                                </td>
                            </tr>
                        </tfoot>
                    </form>

                </table>
            </div>
        </div>
    </div>
</div>
@endsection

@section('modal')

@endsection

@section('footer-script')

@endsection