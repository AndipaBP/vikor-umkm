@extends('dashboard.layout.main')

@section('title-page')
UMKM | PENILAIAN
@endsection

@section('header-script')

@endsection

@section('page-header')
UMKM | PENILAIAN
@endsection

@section('page-navigation')
<li class="breadcrumb-item"><a href="{{url('/umkm')}}">UMKM</a> </li>
<li class="breadcrumb-item">PENILAIAN</li>
@endsection

@section('content')
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">PENILAIAN</h5>
            <div class="float-right">
                <h5>Nama Pemilik : {{$umkm->nama}} | Nama Usaha : {{$umkm->nama_usaha}}</h5>

            </div>
        </div>
        <div class="card-body table-border-style">
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th width="1%">No.</th>
                            <th>Kriteria</th>
                            <th>Nilai</th>
                        </tr>
                    </thead>
                    <form action="{{url()->current()}}/simpan" method="post">
                        @csrf
                        @method('PUT')
                        <tbody>
                    
                        @php
                        $no = 1;
                        @endphp

                        @for ($i = 0; $i < count($kriteria); $i++)
                            <tr>
                                <td>{{$no++}}.</td>
                                <td>{{$kriteria[$i]['nama']}}</td>
                                <td>
                            
                                    <div class="form-group">
                                        <select class="form-control" name="{{$kriteria[$i]['penilaian_id']}}-kriteria-{{$kriteria[$i]['id']}}" required>
                                            <option value="" selected disabled>--- Pilih ---</option>

                                            @for ($j = 0; $j < count($kriteria[$i]['sub_kriteria']); $j++)

                                            <option {{$kriteria[$i]['sub_kriteria'][$j]['value']}} value="{{$kriteria[$i]['sub_kriteria'][$j]['id']}}">{{$kriteria[$i]['sub_kriteria'][$j]['pilihan']}}</option>
                                                
                                            @endfor
                                    
                                        </select>
                                    </div>
                                    

                                </td>
                            </tr>
                    
                        @endfor
                            
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="3">
                                    <div class="float-right">
                                        <button class="btn btn-success"><i class="feather icon-save"></i> Simpan</button>

                                    </div>
                                </td>
                            </tr>
                        </tfoot>
                    </form>

                </table>
            </div>
        </div>
    </div>
</div>
@endsection

@section('modal')

@endsection

@section('footer-script')

@endsection