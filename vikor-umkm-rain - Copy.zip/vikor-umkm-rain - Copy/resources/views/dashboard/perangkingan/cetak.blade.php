<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Cetak Laporan</title>

    <style>

        #title-laporan{
            margin-bottom: 10px;

        }

        td{
            /* border-bottom: 1px solid black; */
            height: 25px;
        }


    </style>
</head>
<body>

    <table id="title-laporan" width="100%">
        <tr>
            <td align="center"><h3>DAFTAR PERANGKINGAN UMKM</h3></td>
        </tr>
        <tr>
            <td>Bidang Usaha : {{$bidang_usaha}}</td>
        </tr>
    </table>
    <table id="daftar-laporan" width="100%" border="1">
        <thead>
            <tr>
                <th>No. </th>
                <th>Nama Pemilik / NIK</th>
                <th>Nama Usaha</th>
                <th>Alamat Usaha</th>
                <th>Nilai Akhir</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($umkm as $row)
            <tr>
                <td>{{$loop->iteration}}.</td>
                <td>{{$row->nama}}</td>
                <td>{{$row->nama_usaha}}</td>
                <td>{{$row->alamat_usaha}}</td>
                <td>{{$row->nilai}}</td>
            </tr>
            @endforeach
        </tbody>

    </table>
    
</body>
</html>