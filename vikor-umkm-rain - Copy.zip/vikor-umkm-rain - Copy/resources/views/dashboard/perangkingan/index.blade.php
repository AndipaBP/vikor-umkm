@extends('dashboard.layout.main')

@section('title-page')
Perangkingan | Bidang Usaha | {{$bidang_usaha}}
@endsection

@section('header-script')

@endsection

@section('page-header')
Perangkingan | Bidang Usaha | {{$bidang_usaha}}
@endsection

@section('page-navigation')
<li class="breadcrumb-item">Perangkingan</li>
<li class="breadcrumb-item"><a href="{{url('/perangkingan')}}">Bidang Usaha</a></li>
<li class="breadcrumb-item">{{$bidang_usaha}}</li>

@endsection

@section('content')
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">PERANGKINGAN</h5>
        </div>
        <div class="card-body table-border-style">
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead class="text-center" >
                        <tr>
                            <th width="1%">Rangking</th>
                            <th style="vertical-align: middle;">Nama Usaha</th>
                            <th>Nilai</th>
                            <th width="10%">Aksi</th>
                        </tr>
                       
                    </thead>
                    <tbody >
                        @foreach ($umkm as $row)
                        <tr>
                            <td class="text-center">{{$loop->iteration}}</td>
                            <td>{{$row->nama_usaha}}</td>
                            <td class="text-center">{{$row->nilai}}</td>
                            <td>
                                <a href="{{url('/umkm')}}/{{$row->umkm_id}}" class="btn btn-sm btn-success"><i class="feather icon-bookmark"></i> Detail</a>
                               
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection

@section('modal')

@endsection

@section('footer-script')

@endsection