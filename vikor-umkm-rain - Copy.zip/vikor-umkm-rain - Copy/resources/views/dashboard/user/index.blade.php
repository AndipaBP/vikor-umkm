@extends('dashboard.layout.main')

@section('title-page')
Dashboard
@endsection

@section('header-script')

@endsection

@section('page-header')
Dashboard
@endsection

@section('page-navigation')

@endsection

@section('content')
<div class="col-md-12">
    <div class="card">
       

        <div class="card-body table-border-style">
            <form action="{{url('/data/ubah')}}/simpan" method="post">
                @csrf
                @method('PUT')
                <div class="row">
                    <div class="col-sm-5">
                        <h6>DATA PRIBADI</h6>
                        <hr>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label for="nik">NIK</label>
                            <input type="text" class="form-control" id="nik" name="nik" placeholder="NIK..." value="{{$umkm->user->username}}" required>
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <div class="form-group">
                            <label for="nama_pemilik">NAMA</label>
                            <input type="text" class="form-control" id="nama_pemilik" name="nama_pemilik" placeholder="Nama..." value="{{$umkm->nama}}" required>
                        </div>
                    </div>
                </div>
              
                <div class="row">
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label for="jenis_kelamin">JENIS KELAMIN</label>
                            <select class="form-control" name="jenis_kelamin" id="jenis_kelamin" required>
                                <option value="" disabled>--- Pilih Jenis Kelamin ---</option>
                                <option value="Laki-Laki" 
                                @if ($umkm->jenis_kelamin == 'Laki-Laki')
                                    selected
                                @endif>Laki-Laki</option>
                                <option value="Perempuan"
                                @if ($umkm->jenis_kelamin == 'Perempuan')
                                    selected
                                @endif
                                >Perempuan</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label for="no_telepon">NO. TELEPON</label>
                            <input type="number" class="form-control" id="no_telepon" name="no_telepon" placeholder="No. Telepon..." value="{{$umkm->no_telepon}}" required>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label for="email">EMAIL</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Email..." value="{{$umkm->user->email}}" required>
                        </div>
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col-sm-5">
                        <h6>DATA USAHA</h6>
                        <hr>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="nama_usaha">NAMA USAHA</label>
                            <input type="text" class="form-control" id="nama_usaha" name="nama_usaha" placeholder="Nama Usaha..." value="{{$umkm->nama_usaha}}" required>
                        </div>
                    </div>
                  
                </div>
                <div class="row">
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label for="tahun_berdiri">TAHUN BERDIRI</label>
                            <input type="number" class="form-control" id="tahun_berdiri" name="tahun_berdiri" placeholder="Tahun Berdiri..." value="{{$umkm->tahun_berdiri}}" required>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label for="bidang_usaha">BIDANG USAHA</label>
                            <select class="form-control" name="bidang_usaha" id="bidang_usaha" required>
                                <option value="" disabled selected>--- Pilih Bidang Usaha ---</option>
                                @foreach ($bidang_usaha as $row)
                                <option value="{{$row->id}}"
                                @if ($umkm->bidang_usaha_id == $row->id)
                                    selected
                                @endif
                                >{{$row->nama}}</option>

                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-8">
                        <div class="form-group">
                            <label for="alamat_usaha">ALAMAT USAHA</label>
                            <input type="text" class="form-control" id="alamat_usaha" name="alamat_usaha" placeholder="Alamat Usaha" value="{{$umkm->alamat_usaha}}" required>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <button type="submit" class="btn btn-success"><i class="feather icon-save"></i> Simpan</button>
                    </div>
                </div>
            </form>
            <div class="row mt-4">
                <div class="col-sm-5">
                    <h6>DETAIL USAHA</h6>
                    <hr>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-5">
                    @if ($umkm->penilaian->count() > 0)
                        <a href="{{url('/data')}}/detail" class="btn btn-info btn-block"><i class="feather icon-align-left"></i> Ubah Detail Usaha</a>
                    @else
                        <a href="{{url('/data')}}/detail" class="btn btn-warning btn-block"><i class="feather icon-alert-circle"></i> Tambah Detail Usaha</a>
                    @endif
                </div>
            </div>
            @if ($umkm->penilaian->count() > 0)
            <div class="row">
                @foreach ($umkm->penilaian as $row)
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="{{$row->kriteria->id}}">{{$row->kriteria->nama}}</label>
                        <input type="text" class="form-control" id="{{$row->kriteria->id}}" name="{{$row->kriteria->id}}" placeholder="..." value="{{$row->sub_kriteria->nama}}" readonly>
                    </div>
                </div>
                @endforeach

            </div>
            @endif
        
        </div>
    </div>
</div>
@endsection

@section('modal')

@endsection

@section('footer-script')

@endsection