@extends('dashboard.layout.main')

@section('title-page')
Bidang Usaha
@endsection

@section('header-script')

@endsection

@section('page-header')
Bidang Usaha
@endsection

@section('page-navigation')
<li class="breadcrumb-item">Bidang Usaha</li>
@endsection

@section('content')
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">DAFTAR BIDANG USAHA</h5>
            <div class="float-right">
                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-tambah">
                    <i class="feather icon-plus"></i> Tambah
                </button>
            </div>
        </div>
        <div class="card-body table-border-style">
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th width="1%">No.</th>
                            <th>Bidang Usaha</th>
                            <th>Jumlah UMKM</th>
                            <th width="12%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($bidang_usaha as $row)
                        <tr>
                            <td>{{$loop->iteration}}.</td>
                            <td>{{$row->nama}}</td>
                            <td>{{$row->umkm()->count()}}</td>
                            <td>
                                <button class="btn btn-sm btn-info" data-toggle="modal" data-target="#modal-ubah" onclick="ubah_bidang_usaha('{{$row->id}}','{{$row->nama}}')"><i class="feather icon-edit"></i> Ubah</button>
                                <button class="btn btn-sm btn-danger" onclick="hapus_data('{{$row->id}}')"><i class="feather icon-delete"></i> Hapus</button>                            
                            </td>
                        </tr>
                            
                        @endforeach
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection

@section('modal')

<div id="modal-tambah" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalLiveLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modal-tambah-label">TAMBAH</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <form action="{{url('/bidang-usaha/tambah/simpan')}}" method="post">
                @csrf
                <div class="modal-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="nama_bidang_usaha">Bidang Usaha</label>
                                <input type="text" class="form-control" id="nama_bidang_usaha" name="nama_bidang_usaha" placeholder="Nama Bidang Usaha..." required>
                            </div>
                        </div>
                   
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn  btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn  btn-primary">Simpan</button>
                </div>
            </form>

        </div>
    </div>
</div>

<div id="modal-ubah" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalLiveLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modal-tambah-label">TAMBAH</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <form action="{{url('/bidang-usaha/ubah/simpan')}}" method="post">
                @csrf
                @method('PUT')
                <input type="hidden" id="id_bidang_usaha" name="id_bidang_usaha">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="ubah_nama_bidang_usaha">Bidang Usaha</label>
                                <input type="text" class="form-control" id="ubah_nama_bidang_usaha" name="ubah_nama_bidang_usaha" placeholder="Nama Bidang Usaha..." required>
                            </div>
                        </div>
                   
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn  btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn  btn-primary">Simpan</button>
                </div>
            </form>

        </div>
    </div>
</div>

@endsection

@section('footer-script')

<script>
    function ubah_bidang_usaha(id, nama){

        $("#id_bidang_usaha").val(id);
        $("#ubah_nama_bidang_usaha").val(nama);

    }

    function hapus_data(id){
        if (confirm("Anda Yakin Ingin Mengapus Data Ini ? ") == true) {

            location.href = "{{url()->current()}}/"+id+"/hapus";
        } 
    }

</script>

@endsection