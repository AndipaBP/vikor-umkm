@extends('dashboard.layout.main')

@section('title-page')
UMKM | Bidang Usaha | {{$bidang_usaha}}
@endsection

@section('header-script')

@endsection

@section('page-header')
UMKM | Bidang Usaha | {{$bidang_usaha}}
@endsection

@section('page-navigation')
<li class="breadcrumb-item">UMKM</li>
<li class="breadcrumb-item"><a href="{{url('/umkm')}}">Bidang Usaha</a> </li>
<li class="breadcrumb-item">{{$bidang_usaha}}</li>


@endsection

@section('content')
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">DAFTAR UMKM</h5>
            <div class="float-right">
                <a href="{{url('/umkm/tambah')}}" class="btn btn-primary btn-sm">
                    <i class="feather icon-plus"></i> Tambah
                </a>
            </div>
        </div>
        <div class="card-body table-border-style">
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th width="1%">No.</th>
                            <th>Nama / NIK</th>
                            <th>Nama Usaha</th>
                            <th>Bidang Usaha</th>
                            <th width="15%">Penilaian</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($umkm as $row)
                        <tr>
                            <td>{{$loop->iteration}}.</td>
                            <td>{{$row->nama}} 
                                <br>
                                <small><strong>NIK : {{$row->user->username}}</strong></small>
                            </td>
                            <td>{{$row->nama_usaha}}</td>
                            <td>{{$row->bidang_usaha->nama}}</td>
                            <td>
                                @if ($row->penilaian->count() > 0)

                                    <a href="{{url('/umkm')}}/{{$row->id}}/penilaian/ubah" class="btn btn-info btn-block"><i class="feather icon-align-left"></i> Ubah Penilaian</a>

                                @else
                                    <a href="{{url('/umkm')}}/{{$row->id}}/penilaian/tambah" class="btn btn-warning btn-block"><i class="feather icon-alert-circle"></i> Belum Dinilai</a>
                                    
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <td colspan="5">
                                <a href="{{url('/umkm')}}/{{$row->id}}" class="btn btn-sm btn-success"><i class="feather icon-bookmark"></i> Detail</a>
                                <a href="{{url('/umkm')}}/{{$row->id}}/ubah" class="btn btn-sm btn-info"><i class="feather icon-edit"></i> Ubah</a>
                                <button onclick="hapus_data({{$row->id}})" class="btn btn-sm btn-danger"><i class="feather icon-delete"></i> Hapus</button>
                            </td>
                        </tr>
                            
                        @endforeach
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection

@section('modal')

@endsection

@section('footer-script')

<script>
     function hapus_data(id){
        if (confirm("Anda Yakin Ingin Mengapus Data Ini ? ") == true) {

            location.href = "{{url()->current()}}/"+id+"/hapus";
        } 
    }
</script>

@endsection