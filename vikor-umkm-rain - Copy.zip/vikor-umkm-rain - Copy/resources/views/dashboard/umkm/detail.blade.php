@extends('dashboard.layout.main')

@section('title-page')
UMKM | DETAIL
@endsection

@section('header-script')

@endsection

@section('page-header')
UMKM | DETAIL
@endsection

@section('page-navigation')
<li class="breadcrumb-item"><a href="{{url('/umkm')}}">UMKM</a> </li>
<li class="breadcrumb-item">DETAIL</li>

@endsection

@section('content')
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">DETAIL UMKM</h5>
        </div>
        <div class="card-body table-border-style">
            <div class="row">
                <div class="col-sm-5">
                    <h6>DATA PRIBADI</h6>
                    <hr>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                        <label for="nik">NIK</label>
                        <input type="text" class="form-control" id="nik" name="nik" placeholder="NIK..." value="{{$umkm->user->username}}" readonly>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="form-group">
                        <label for="nama_pemilik">NAMA</label>
                        <input type="text" class="form-control" id="nama_pemilik" name="nama_pemilik" placeholder="Nama..." value="{{$umkm->nama}}" readonly>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-sm-3">
                    <div class="form-group">
                        <label for="jenis_kelamin">JENIS KELAMIN</label>
                        <input type="text" class="form-control" id="jenis_kelamin" name="jenis_kelamin" placeholder="Jenis Kelamin..." value="{{$umkm->jenis_kelamin}}" readonly>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <label for="no_telepon">NO. TELEPON</label>
                        <input type="number" class="form-control" id="no_telepon" name="no_telepon" placeholder="No. Telepon..." value="{{$umkm->no_telepon}}" readonly>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                        <label for="email">EMAIL</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Email..." value="{{$umkm->user->email}}" readonly>
                    </div>
                </div>
            </div>
            <div class="row mt-2">
                <div class="col-sm-5">
                    <h6>DATA USAHA</h6>
                    <hr>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="nama_usaha">NAMA USAHA</label>
                        <input type="text" class="form-control" id="nama_usaha" name="nama_usaha" placeholder="Nama Usaha..." value="{{$umkm->nama_usaha}}" readonly>
                    </div>
                </div>
                
            </div>
            <div class="row">
                <div class="col-sm-3">
                    <div class="form-group">
                        <label for="tahun_berdiri">TAHUN BERDIRI</label>
                        <input type="number" class="form-control" id="tahun_berdiri" name="tahun_berdiri" placeholder="Tahun Berdiri..." value="{{$umkm->tahun_berdiri}}" readonly>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <label for="bidang_usaha">BIDANG USAHA</label>
                        <input type="text" class="form-control" id="bidang_usaha" name="bidang_usaha" placeholder="Bidang Usaha..." value="{{$umkm->bidang_usaha->nama}}" readonly>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-8">
                    <div class="form-group">
                        <label for="alamat_usaha">ALAMAT USAHA</label>
                        <input type="text" class="form-control" id="alamat_usaha" name="alamat_usaha" placeholder="Alamat Usaha..." value="{{$umkm->alamat_usaha}}" readonly>
                    </div>
                </div>
            </div>
            @if ($umkm->penilaian->count() > 0)
            <div class="row mt-2">
                <div class="col-sm-5">
                    <h6>PENILAIAN USAHA</h6>
                    <hr>
                </div>
            </div>
            <div class="row">

                @foreach ($umkm->penilaian as $row)
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="{{$row->kriteria->id}}">{{$row->kriteria->nama}}</label>
                        <input type="text" class="form-control" id="{{$row->kriteria->id}}" name="{{$row->kriteria->id}}" placeholder="..." value="{{$row->sub_kriteria->nama}}" readonly>
                    </div>
                </div>
                @endforeach

            </div>
            @endif
        </div>
    </div>
</div>
@endsection

@section('modal')

@endsection

@section('footer-script')

@endsection