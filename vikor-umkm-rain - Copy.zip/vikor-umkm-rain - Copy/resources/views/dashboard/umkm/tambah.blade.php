@extends('dashboard.layout.main')

@section('title-page')
UMKM | TAMBAH
@endsection

@section('header-script')

@endsection

@section('page-header')
UMKM | TAMBAH
@endsection

@section('page-navigation')
<li class="breadcrumb-item"><a href="{{url('/umkm')}}">UMKM</a> </li>
<li class="breadcrumb-item">TAMBAH</li>

@endsection

@section('content')
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">TAMBAH UMKM</h5>
        </div>
        <div class="card-body table-border-style">
            <form action="{{url()->current()}}/simpan" method="post">
                @csrf
                <div class="row">
                    <div class="col-sm-5">
                        <h6>DATA PRIBADI</h6>
                        <hr>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label for="nik">NIK</label>
                            <input type="text" class="form-control" id="nik" name="nik" placeholder="NIK..." required>
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <div class="form-group">
                            <label for="nama_pemilik">NAMA</label>
                            <input type="text" class="form-control" id="nama_pemilik" name="nama_pemilik" placeholder="Nama..." required>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label for="jenis_kelamin">JENIS KELAMIN</label>
                            <select class="form-control" name="jenis_kelamin" id="jenis_kelamin" required>
                                <option value="" disabled selected>--- Pilih Jenis Kelamin ---</option>
                                <option value="Laki-Laki">Laki-Laki</option>
                                <option value="Perempuan">Perempuan</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label for="no_telepon">NO. TELEPON</label>
                            <input type="number" class="form-control" id="no_telepon" name="no_telepon" placeholder="No. Telepon..." required>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label for="email">EMAIL</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Email..." required>
                        </div>
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col-sm-5">
                        <h6>DATA USAHA</h6>
                        <hr>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="nama_usaha">NAMA USAHA</label>
                            <input type="text" class="form-control" id="nama_usaha" name="nama_usaha" placeholder="Nama Usaha..." required>
                        </div>
                    </div>
                  
                </div>
                <div class="row">
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label for="tahun_berdiri">TAHUN BERDIRI</label>
                            <input type="number" class="form-control" id="tahun_berdiri" name="tahun_berdiri" placeholder="Tahun Berdiri..." required>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label for="bidang_usaha">BIDANG USAHA</label>
                            <select class="form-control" name="bidang_usaha" id="bidang_usaha" required>
                                <option value="" disabled selected>--- Pilih Bidang Usaha ---</option>
                                @foreach ($bidang_usaha as $row)
                                <option value="{{$row->id}}">{{$row->nama}}</option>

                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-8">
                        <div class="form-group">
                            <label for="alamat_usaha">ALAMAT USAHA</label>
                            <input type="text" class="form-control" id="alamat_usaha" name="alamat_usaha" placeholder="Alamat Usaha" required>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <button type="submit" class="btn btn-success"><i class="feather icon-save"></i> Simpan</button>

                    </div>
                </div>
            </form>
        
        </div>
    </div>
</div>
@endsection

@section('modal')

@endsection

@section('footer-script')

@endsection