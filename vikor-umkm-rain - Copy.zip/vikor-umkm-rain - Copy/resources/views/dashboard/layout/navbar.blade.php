<nav class="pcoded-navbar  ">
    <div class="navbar-wrapper  ">
        <div class="navbar-content scroll-div " >
            
            <div class="">
                <div class="main-menu-header">
                  
                    <div class="user-details">
                        @if (Auth::user()->roles_id == 1)
                        <span>{{ucwords(Auth::user()->username)}}</span>

                        @else
                        <span>{{Auth::user()->username}}</span>
                        <div>{{Auth::user()->roles->nama}}</div>
                        @endif
                       
                    </div>
                </div>
            
            </div>
            
            <ul class="nav pcoded-inner-navbar ">
                <li class="nav-item pcoded-menu-caption">
                    <label>Home</label>
                </li>
                <li class="nav-item">
                    <a href="{{url('/')}}" class="nav-link "><span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>
                </li>
                @if (Auth::user()->roles_id == 1)
                <li class="nav-item pcoded-menu-caption">
                    <label>UMKM</label>
                </li>
                <li class="nav-item">
                    <a href="{{url('/bidang-usaha')}}" class="nav-link "><span class="pcoded-micon"><i class="feather icon-filter"></i></span><span class="pcoded-mtext">Bidang Usaha</span></a>
                </li>
                <li class="nav-item">
                    <a href="{{url('/umkm')}}" class="nav-link "><span class="pcoded-micon"><i class="feather icon-user"></i></span><span class="pcoded-mtext">Daftar UMKM</span></a>
                </li>
                <li class="nav-item pcoded-menu-caption">
                    <label>Perangkingan</label>
                </li>
                <li class="nav-item">
                    <a href="{{url('/perhitungan')}}" class="nav-link "><span class="pcoded-micon"><i class="feather icon-grid"></i></span><span class="pcoded-mtext">Perhitungan</span></a>
                </li>
                <li class="nav-item">
                    <a href="{{url('/perangkingan')}}" class="nav-link "><span class="pcoded-micon"><i class="feather icon-check"></i></span><span class="pcoded-mtext">Lihat Rangking</span></a>
                </li>
                    
                @endif
                @if (Auth::user()->roles_id == 2)
                <li class="nav-item pcoded-menu-caption">
                    <label>UMKM</label>
                </li>
                <li class="nav-item">
                    <a href="{{url('/data')}}" class="nav-link "><span class="pcoded-micon"><i class="feather icon-user"></i></span><span class="pcoded-mtext">Data Usaha</span></a>
                </li>
                <li class="nav-item">
                    <a href="{{url('/data/detail')}}" class="nav-link "><span class="pcoded-micon"><i class="feather icon-filter"></i></span><span class="pcoded-mtext">Detail Usaha</span></a>
                </li>
                    
                @endif
             
         
            </ul>
        
            
        </div>
    </div>
</nav>