<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\Dashboard\DashboardController;
use App\Http\Controllers\Dashboard\BidangUsahaController;
use App\Http\Controllers\Dashboard\UmkmController;
use App\Http\Controllers\Dashboard\PerhitunganController;
use App\Http\Controllers\Dashboard\PerangkinganController;
use App\Http\Controllers\Dashboard\UserController;



/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::group(['middleware'=> 'guest'], function() {

    Route::get('/sign-in', [AuthController::class, 'sign_in']);
    Route::post('/sign-in', [AuthController::class, 'post_sign_in'])->name('login');

    Route::get('/sign-up', [AuthController::class, 'sign_up']);
    Route::post('/sign-up', [AuthController::class, 'post_sign_up'])->name('sign_up');

    Route::get('/sign-up/langkah-kedua', [AuthController::class, 'sign_up_2']);
    Route::post('/sign-up/langkah-kedua', [AuthController::class, 'post_sign_up_2'])->name('sign_up_2');

    Route::get('/sign-up/langkah-ketiga', [AuthController::class, 'sign_up_3']);    
    Route::post('/sign-up/langkah-ketiga', [AuthController::class, 'post_sign_up_3'])->name('sign_up_3');    

});

Route::group(['middleware'=> 'auth'], function() {

    Route::get('/sign-out', [AuthController::class, 'sign_out']);
    Route::put('/change-password', [AuthController::class, 'change_password']);

    Route::get('/', [DashboardController::class, 'index']);

    Route::group(['middleware'=> 'checkrole:admin'], function() {

        Route::get('/umkm', [UmkmController::class, 'daftar_bidang_usaha']);
    
        Route::get('/umkm/bidang-usaha/{id}', [UmkmController::class, 'index']);
        Route::get('/umkm/tambah', [UmkmController::class, 'tambah']);
        Route::post('/umkm/tambah/simpan', [UmkmController::class, 'simpan']);
        Route::get('/umkm/{id}', [UmkmController::class, 'detail_umkm']);
        Route::get('/umkm/{id}/ubah', [UmkmController::class, 'ubah_umkm']);
        Route::put('/umkm/{id}/ubah/simpan', [UmkmController::class, 'simpan_ubah_umkm']);
        Route::get('/umkm/{id}/penilaian/tambah', [UmkmController::class, 'tambah_penilaian']);
        Route::post('/umkm/{id}/penilaian/tambah/simpan', [UmkmController::class, 'simpan_penilaian']);
        Route::get('/umkm/{id}/penilaian/ubah', [UmkmController::class, 'ubah_penilaian']);
        Route::put('/umkm/{id}/penilaian/ubah/simpan', [UmkmController::class, 'simpan_ubah_penilaian']);
        Route::get('/umkm/{id}/hapus', [UmkmController::class, 'hapus_umkm']);
        
        
        Route::get('/bidang-usaha',[BidangUsahaController::class, 'index']);
        Route::post('/bidang-usaha/tambah/simpan',[BidangUsahaController::class, 'tambah_simpan']);
        Route::put('/bidang-usaha/ubah/simpan',[BidangUsahaController::class, 'ubah_simpan']);
        Route::get('/bidang-usaha/{id}/hapus',[BidangUsahaController::class, 'hapus']);
        
        
        Route::get('/perhitungan', [PerhitunganController::class, 'bidang_usaha']);
        Route::get('/perhitungan/bidang-usaha/{id}', [PerhitunganController::class, 'index']);
        
        Route::get('/perangkingan', [PerangkinganController::class, 'bidang_usaha']);
        Route::get('/perangkingan/bidang-usaha/{id}', [PerangkinganController::class, 'index']);
        Route::get('/perangkingan/bidang-usaha/{id}/cetak', [PerangkinganController::class, 'cetak_laporan']);




    });

    Route::group(['middleware'=> 'checkrole:umkm'], function() {

        Route::get('/data', [DashboardController::class, 'index']);
        Route::put('/data/ubah/simpan', [UserController::class, 'simpan_ubah']);
        Route::get('/data/detail', [UserController::class, 'penilaian']);
        Route::post('/data/detail/tambah/simpan', [UserController::class, 'simpan_penilaian']);
        Route::put('/data/detail/ubah/simpan', [UserController::class, 'simpan_ubah_penilaian']);
    
    });
});




