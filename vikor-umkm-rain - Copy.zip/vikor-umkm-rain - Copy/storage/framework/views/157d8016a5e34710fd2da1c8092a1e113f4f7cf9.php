<header class="navbar pcoded-header navbar-expand-lg navbar-light header-dark">

    <div class="m-header" style="justify-content: left;">
        <a class="mobile-menu" id="mobile-collapse" href="#!"><span></span></a>
        <a href="#!" class="b-brand">
            SPK UMKM
        </a>
        <a href="#!" class="mob-toggler">
            <i class="feather icon-more-vertical"></i>
        </a>
    </div>
    <div class="collapse navbar-collapse">
        
        <ul class="navbar-nav ml-auto">
            <li>
                <div class="dropdown drp-user">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="feather icon-user"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right profile-notification">
                        <div class="pro-head">
                            
                            <span><?php echo e(ucwords(Auth::user()->username)); ?></span>
                            <a href="<?php echo e(url('/sign-out')); ?>" class="dud-logout" title="Logout">
                                <i class="feather icon-log-out"></i>
                            </a>
                        </div>
                        <ul class="pro-body">
                            <li><a href="#" class="dropdown-item" data-toggle="modal" data-target="#modal-change-password"><i class="feather icon-lock"></i> Ubah Password</a></li>
                        </ul>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</header><?php /**PATH D:\xampp\htdocs\vikor-umkm-rain\resources\views/dashboard/layout/header.blade.php ENDPATH**/ ?>