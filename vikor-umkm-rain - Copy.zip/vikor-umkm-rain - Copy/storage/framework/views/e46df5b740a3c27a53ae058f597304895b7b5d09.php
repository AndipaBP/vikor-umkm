

<?php $__env->startSection('title-page'); ?>
Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-script'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-navigation'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
       

        <div class="card-body table-border-style">
            <form action="<?php echo e(url('/data/ubah')); ?>/simpan" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row">
                    <div class="col-sm-5">
                        <h6>DATA PRIBADI</h6>
                        <hr>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label for="nik">NIK</label>
                            <input type="text" class="form-control" id="nik" name="nik" placeholder="NIK..." value="<?php echo e($umkm->user->username); ?>" required>
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <div class="form-group">
                            <label for="nama_pemilik">NAMA</label>
                            <input type="text" class="form-control" id="nama_pemilik" name="nama_pemilik" placeholder="Nama..." value="<?php echo e($umkm->nama); ?>" required>
                        </div>
                    </div>
                </div>
              
                <div class="row">
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label for="jenis_kelamin">JENIS KELAMIN</label>
                            <select class="form-control" name="jenis_kelamin" id="jenis_kelamin" required>
                                <option value="" disabled>--- Pilih Jenis Kelamin ---</option>
                                <option value="Laki-Laki" 
                                <?php if($umkm->jenis_kelamin == 'Laki-Laki'): ?>
                                    selected
                                <?php endif; ?>>Laki-Laki</option>
                                <option value="Perempuan"
                                <?php if($umkm->jenis_kelamin == 'Perempuan'): ?>
                                    selected
                                <?php endif; ?>
                                >Perempuan</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label for="no_telepon">NO. TELEPON</label>
                            <input type="number" class="form-control" id="no_telepon" name="no_telepon" placeholder="No. Telepon..." value="<?php echo e($umkm->no_telepon); ?>" required>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label for="email">EMAIL</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Email..." value="<?php echo e($umkm->user->email); ?>" required>
                        </div>
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col-sm-5">
                        <h6>DATA USAHA</h6>
                        <hr>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="nama_usaha">NAMA USAHA</label>
                            <input type="text" class="form-control" id="nama_usaha" name="nama_usaha" placeholder="Nama Usaha..." value="<?php echo e($umkm->nama_usaha); ?>" required>
                        </div>
                    </div>
                  
                </div>
                <div class="row">
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label for="tahun_berdiri">TAHUN BERDIRI</label>
                            <input type="number" class="form-control" id="tahun_berdiri" name="tahun_berdiri" placeholder="Tahun Berdiri..." value="<?php echo e($umkm->tahun_berdiri); ?>" required>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label for="bidang_usaha">BIDANG USAHA</label>
                            <select class="form-control" name="bidang_usaha" id="bidang_usaha" required>
                                <option value="" disabled selected>--- Pilih Bidang Usaha ---</option>
                                <?php $__currentLoopData = $bidang_usaha; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->id); ?>"
                                <?php if($umkm->bidang_usaha_id == $row->id): ?>
                                    selected
                                <?php endif; ?>
                                ><?php echo e($row->nama); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-8">
                        <div class="form-group">
                            <label for="alamat_usaha">ALAMAT USAHA</label>
                            <input type="text" class="form-control" id="alamat_usaha" name="alamat_usaha" placeholder="Alamat Usaha" value="<?php echo e($umkm->alamat_usaha); ?>" required>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <button type="submit" class="btn btn-success"><i class="feather icon-save"></i> Simpan</button>
                    </div>
                </div>
            </form>
            <div class="row mt-4">
                <div class="col-sm-5">
                    <h6>DETAIL USAHA</h6>
                    <hr>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-5">
                    <?php if($umkm->penilaian->count() > 0): ?>
                        <a href="<?php echo e(url('/data')); ?>/detail" class="btn btn-info btn-block"><i class="feather icon-align-left"></i> Ubah Detail Usaha</a>
                    <?php else: ?>
                        <a href="<?php echo e(url('/data')); ?>/detail" class="btn btn-warning btn-block"><i class="feather icon-alert-circle"></i> Tambah Detail Usaha</a>
                    <?php endif; ?>
                </div>
            </div>
            <?php if($umkm->penilaian->count() > 0): ?>
            <div class="row">
                <?php $__currentLoopData = $umkm->penilaian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="<?php echo e($row->kriteria->id); ?>"><?php echo e($row->kriteria->nama); ?></label>
                        <input type="text" class="form-control" id="<?php echo e($row->kriteria->id); ?>" name="<?php echo e($row->kriteria->id); ?>" placeholder="..." value="<?php echo e($row->sub_kriteria->nama); ?>" readonly>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <?php endif; ?>
        
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\vikor-umkm-rain\resources\views/dashboard/user/index.blade.php ENDPATH**/ ?>