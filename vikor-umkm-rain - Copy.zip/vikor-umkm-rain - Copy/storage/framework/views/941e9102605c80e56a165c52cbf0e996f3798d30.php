

<?php $__env->startSection('title-page'); ?>
Perangkingan | Bidang Usaha | <?php echo e($bidang_usaha); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-script'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
Perangkingan | Bidang Usaha | <?php echo e($bidang_usaha); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-navigation'); ?>
<li class="breadcrumb-item">Perangkingan</li>
<li class="breadcrumb-item"><a href="<?php echo e(url('/perangkingan')); ?>">Bidang Usaha</a></li>
<li class="breadcrumb-item"><?php echo e($bidang_usaha); ?></li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">PERANGKINGAN</h5>
        </div>
        <div class="card-body table-border-style">
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead class="text-center" >
                        <tr>
                            <th width="1%">Rangking</th>
                            <th style="vertical-align: middle;">Nama Usaha</th>
                            <th>Nilai</th>
                            <th width="10%">Aksi</th>
                        </tr>
                       
                    </thead>
                    <tbody >
                        <?php $__currentLoopData = $umkm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($row->nama_usaha); ?></td>
                            <td class="text-center"><?php echo e($row->nilai); ?></td>
                            <td>
                                <a href="<?php echo e(url('/umkm')); ?>/<?php echo e($row->umkm_id); ?>" class="btn btn-sm btn-success"><i class="feather icon-bookmark"></i> Detail</a>
                                <a href="<?php echo e(url('/umkm')); ?>/<?php echo e($row->umkm_id); ?>/cetak" class="btn btn-sm btn-info"><i class="feather icon-printer"></i> Cetak</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\vikor-umkm-rain\resources\views/dashboard/perangkingan/index.blade.php ENDPATH**/ ?>