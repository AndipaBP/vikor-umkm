

<?php $__env->startSection('title-page'); ?>
UMKM | PENILAIAN
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-script'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
UMKM | PENILAIAN
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-navigation'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(url('/umkm')); ?>">UMKM</a> </li>
<li class="breadcrumb-item">PENILAIAN</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">PENILAIAN</h5>
            <div class="float-right">
                <h5>Nama Pemilik : <?php echo e($umkm->nama); ?> | Nama Usaha : <?php echo e($umkm->nama_usaha); ?></h5>

            </div>
        </div>
        <div class="card-body table-border-style">
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th width="1%">No.</th>
                            <th>Kriteria</th>
                            <th>Nilai</th>
                        </tr>
                    </thead>
                    <form action="<?php echo e(url()->current()); ?>/simpan" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <tbody>
                    
                        <?php
                        $no = 1;
                        ?>

                        <?php for($i = 0; $i < count($kriteria); $i++): ?>
                            <tr>
                                <td><?php echo e($no++); ?>.</td>
                                <td><?php echo e($kriteria[$i]['nama']); ?></td>
                                <td>
                            
                                    <div class="form-group">
                                        <select class="form-control" name="<?php echo e($kriteria[$i]['penilaian_id']); ?>-kriteria-<?php echo e($kriteria[$i]['id']); ?>" required>
                                            <option value="" selected disabled>--- Pilih ---</option>

                                            <?php for($j = 0; $j < count($kriteria[$i]['sub_kriteria']); $j++): ?>

                                            <option <?php echo e($kriteria[$i]['sub_kriteria'][$j]['value']); ?> value="<?php echo e($kriteria[$i]['sub_kriteria'][$j]['id']); ?>"><?php echo e($kriteria[$i]['sub_kriteria'][$j]['pilihan']); ?></option>
                                                
                                            <?php endfor; ?>
                                    
                                        </select>
                                    </div>
                                    

                                </td>
                            </tr>
                    
                        <?php endfor; ?>
                            
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="3">
                                    <div class="float-right">
                                        <button class="btn btn-success"><i class="feather icon-save"></i> Simpan</button>

                                    </div>
                                </td>
                            </tr>
                        </tfoot>
                    </form>

                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\vikor-umkm-rain\resources\views/dashboard/umkm_penilaian/ubah.blade.php ENDPATH**/ ?>