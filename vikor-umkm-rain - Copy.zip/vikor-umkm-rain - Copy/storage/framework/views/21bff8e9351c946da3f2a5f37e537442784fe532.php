

<?php $__env->startSection('title-page'); ?>
Perhitungan | Bidang Usaha
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-script'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
Perhitungan | Bidang Usaha
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-navigation'); ?>
<li class="breadcrumb-item">Perhitungan</li>
<li class="breadcrumb-item">Bidang Usaha</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">DAFTAR BIDANG USAHA</h5>
         
        </div>
        <div class="card-body table-border-style">
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th width="1%">No.</th>
                            <th>Bidang Usaha</th>
                            <th>Jumlah UMKM</th>
                            <th width="12%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
          
                        <?php $__currentLoopData = $bidang_usaha; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?>.</td>
                            <td><?php echo e($row->nama); ?></td>
                            <td><?php echo e($row->umkm()->count()); ?></td>
                            <td><a href="<?php echo e(url('/perhitungan/bidang-usaha')); ?>/<?php echo e($row->id); ?>" class="btn btn-sm btn-success"><i class="feather icon-bar-chart"></i> Mulai Perhitungan</a></td>
                        </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\vikor-umkm-rain\resources\views/dashboard/perhitungan/daftar_bidang.blade.php ENDPATH**/ ?>