<nav class="pcoded-navbar  ">
    <div class="navbar-wrapper  ">
        <div class="navbar-content scroll-div " >
            
            <div class="">
                <div class="main-menu-header">
                  
                    <div class="user-details">
                        <?php if(Auth::user()->roles_id == 1): ?>
                        <span><?php echo e(ucwords(Auth::user()->username)); ?></span>

                        <?php else: ?>
                        <span><?php echo e(Auth::user()->username); ?></span>
                        <div><?php echo e(Auth::user()->roles->nama); ?></div>
                        <?php endif; ?>
                       
                    </div>
                </div>
            
            </div>
            
            <ul class="nav pcoded-inner-navbar ">
                <li class="nav-item pcoded-menu-caption">
                    <label>Home</label>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(url('/')); ?>" class="nav-link "><span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>
                </li>
                <?php if(Auth::user()->roles_id == 1): ?>
                <li class="nav-item pcoded-menu-caption">
                    <label>UMKM</label>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(url('/bidang-usaha')); ?>" class="nav-link "><span class="pcoded-micon"><i class="feather icon-filter"></i></span><span class="pcoded-mtext">Bidang Usaha</span></a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(url('/umkm')); ?>" class="nav-link "><span class="pcoded-micon"><i class="feather icon-user"></i></span><span class="pcoded-mtext">Daftar UMKM</span></a>
                </li>
                <li class="nav-item pcoded-menu-caption">
                    <label>Perangkingan</label>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(url('/perhitungan')); ?>" class="nav-link "><span class="pcoded-micon"><i class="feather icon-grid"></i></span><span class="pcoded-mtext">Perhitungan</span></a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(url('/perangkingan')); ?>" class="nav-link "><span class="pcoded-micon"><i class="feather icon-check"></i></span><span class="pcoded-mtext">Lihat Rangking</span></a>
                </li>
                    
                <?php endif; ?>
                <?php if(Auth::user()->roles_id == 2): ?>
                <li class="nav-item pcoded-menu-caption">
                    <label>UMKM</label>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(url('/data')); ?>" class="nav-link "><span class="pcoded-micon"><i class="feather icon-user"></i></span><span class="pcoded-mtext">Data Usaha</span></a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(url('/data/detail')); ?>" class="nav-link "><span class="pcoded-micon"><i class="feather icon-filter"></i></span><span class="pcoded-mtext">Detail Usaha</span></a>
                </li>
                    
                <?php endif; ?>
             
         
            </ul>
        
            
        </div>
    </div>
</nav><?php /**PATH D:\xampp\htdocs\vikor-umkm-rain\resources\views/dashboard/layout/navbar.blade.php ENDPATH**/ ?>