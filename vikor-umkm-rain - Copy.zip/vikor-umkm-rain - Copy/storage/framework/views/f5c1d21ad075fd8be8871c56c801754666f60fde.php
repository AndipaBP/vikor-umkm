

<?php $__env->startSection('title-page'); ?>
UMKM | Bidang Usaha | <?php echo e($bidang_usaha); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-script'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
UMKM | Bidang Usaha | <?php echo e($bidang_usaha); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-navigation'); ?>
<li class="breadcrumb-item">UMKM</li>
<li class="breadcrumb-item"><a href="<?php echo e(url('/umkm')); ?>">Bidang Usaha</a> </li>
<li class="breadcrumb-item"><?php echo e($bidang_usaha); ?></li>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">DAFTAR UMKM</h5>
            <div class="float-right">
                <a href="<?php echo e(url('/umkm/tambah')); ?>" class="btn btn-primary btn-sm">
                    <i class="feather icon-plus"></i> Tambah
                </a>
            </div>
        </div>
        <div class="card-body table-border-style">
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th width="1%">No.</th>
                            <th>Nama / NIK</th>
                            <th>Nama Usaha</th>
                            <th>Bidang Usaha</th>
                            <th width="15%">Penilaian</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $umkm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?>.</td>
                            <td><?php echo e($row->nama); ?> 
                                <br>
                                <small><strong>NIK : <?php echo e($row->user->username); ?></strong></small>
                            </td>
                            <td><?php echo e($row->nama_usaha); ?></td>
                            <td><?php echo e($row->bidang_usaha->nama); ?></td>
                            <td>
                                <?php if($row->penilaian->count() > 0): ?>

                                    <a href="<?php echo e(url('/umkm')); ?>/<?php echo e($row->id); ?>/penilaian/ubah" class="btn btn-info btn-block"><i class="feather icon-align-left"></i> Ubah Penilaian</a>

                                <?php else: ?>
                                    <a href="<?php echo e(url('/umkm')); ?>/<?php echo e($row->id); ?>/penilaian/tambah" class="btn btn-warning btn-block"><i class="feather icon-alert-circle"></i> Belum Dinilai</a>
                                    
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="5">
                                <a href="<?php echo e(url('/umkm')); ?>/<?php echo e($row->id); ?>" class="btn btn-sm btn-success"><i class="feather icon-bookmark"></i> Detail</a>
                                <a href="<?php echo e(url('/umkm')); ?>/<?php echo e($row->id); ?>/ubah" class="btn btn-sm btn-info"><i class="feather icon-edit"></i> Ubah</a>
                                <button onclick="hapus_data(<?php echo e($row->id); ?>)" class="btn btn-sm btn-danger"><i class="feather icon-delete"></i> Hapus</button>
                            </td>
                        </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-script'); ?>

<script>
     function hapus_data(id){
        if (confirm("Anda Yakin Ingin Mengapus Data Ini ? ") == true) {

            location.href = "<?php echo e(url()->current()); ?>/"+id+"/hapus";
        } 
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\vikor-umkm-rain\resources\views/dashboard/umkm/index.blade.php ENDPATH**/ ?>