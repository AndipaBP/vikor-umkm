<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Cetak Laporan</title>

    <style>

        #title-laporan{
            margin-bottom: 10px;

        }

        td{
            /* border-bottom: 1px solid black; */
            height: 25px;
        }


    </style>
</head>
<body>

    <table id="title-laporan" width="100%">
        <tr>
            <td align="center"><h3>DAFTAR PERANGKINGAN UMKM</h3></td>
        </tr>
        <tr>
            <td>Bidang Usaha : <?php echo e($bidang_usaha); ?></td>
        </tr>
    </table>
    <table id="daftar-laporan" width="100%" border="1">
        <thead>
            <tr>
                <th>No. </th>
                <th>Nama Pemilik / NIK</th>
                <th>Nama Usaha</th>
                <th>Alamat Usaha</th>
                <th>Nilai Akhir</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $umkm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?>.</td>
                <td><?php echo e($row->nama); ?></td>
                <td><?php echo e($row->nama_usaha); ?></td>
                <td><?php echo e($row->alamat_usaha); ?></td>
                <td><?php echo e($row->nilai); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
    
</body>
</html><?php /**PATH D:\xampp\htdocs\vikor-umkm-rain\resources\views/dashboard/perangkingan/cetak.blade.php ENDPATH**/ ?>