

<?php $__env->startSection('title-page'); ?>
Perhitungan | Bidang Usaha | <?php echo e($bidang_usaha); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-script'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
Perhitungan | Bidang Usaha | <?php echo e($bidang_usaha); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-navigation'); ?>
<li class="breadcrumb-item">Perhitungan</li>
<li class="breadcrumb-item"><a href="<?php echo e(url('/perhitungan')); ?>">Bidang Usaha</a></li>
<li class="breadcrumb-item"><?php echo e($bidang_usaha); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">MATRIKS KEPUTUSAN (F)</h5>
        </div>
        <div class="card-body table-border-style">
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead class="text-center" >
                        <tr>
                            <th style="vertical-align: middle;" rowspan="2">Nama Usaha</th>
                            <th colspan="<?php echo e($jumlah_kriteria); ?>">Kriteria</th>
                        </tr>
                        <tr>
                            <?php for($i = 1; $i <= $jumlah_kriteria; $i++): ?> 
                                <th>K<?php echo e($i); ?></th>
                            <?php endfor; ?>
                        </tr>
                    </thead>
                    <tbody>
            
                       
                        
                       <?php $__currentLoopData = $matriks_keputusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                       <tr>
                            <td><?php echo e($row['nama_usaha']); ?></td>
                            <?php $__currentLoopData = $row['penilaian']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria => $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td align="center"><?php echo e($nilai); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">MATRIKS NORMALISASI (N)</h5>
        </div>
        <div class="card-body table-border-style">
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead class="text-center" >
                        <tr>
                            <th style="vertical-align: middle;" rowspan="2">Nama Usaha</th>
                            <th colspan="<?php echo e($jumlah_kriteria); ?>">Kriteria</th>
                        </tr>
                        <tr>
                            <?php for($i = 1; $i <= $jumlah_kriteria; $i++): ?> 
                                <th>K<?php echo e($i); ?></th>
                            <?php endfor; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $matriks_normalisasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($row['nama_usaha']); ?></td>
                            <?php $__currentLoopData = $row['nilai']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria => $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td align="center"><?php echo e($nilai); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">MATRIKS NORMALISASI TERBOBOT (F*)</h5>
        </div>
        <div class="card-body table-border-style">
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead class="text-center" >
                        <tr>
                            <th style="vertical-align: middle;" rowspan="2">Nama Usaha</th>
                            <th colspan="<?php echo e($jumlah_kriteria); ?>">Kriteria</th>
                        </tr>
                        <tr>
                            <?php for($i = 1; $i <= $jumlah_kriteria; $i++): ?> 
                                <th>K<?php echo e($i); ?></th>
                            <?php endfor; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $matriks_normalisasi_terbobot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($row['nama_usaha']); ?></td>
                            <?php $__currentLoopData = $row['nilai']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria => $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td align="center"><?php echo e($nilai); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">PERANGKINGAN</h5>
        </div>
        <div class="card-body table-border-style">
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead class="text-center" >
                        <tr>
                            <th width="1%">Rangking</th>
                            <th style="vertical-align: middle;">Nama Usaha</th>
                            <th>Nilai</th>
                        </tr>
                       
                    </thead>
                    <tbody >
                        <?php $__currentLoopData = $matriks_perangkingan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($row->nama_usaha); ?></td>
                            <td class="text-center"><?php echo e($row->nilai); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-script'); ?>

<script>



</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\vikor-umkm-rain\resources\views/dashboard/perhitungan/index.blade.php ENDPATH**/ ?>