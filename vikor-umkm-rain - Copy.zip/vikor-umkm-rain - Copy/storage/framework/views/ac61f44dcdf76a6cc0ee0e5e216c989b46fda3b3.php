

<?php $__env->startSection('title-page'); ?>
DASHBOARD
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-script'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
DASHBOARD
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-navigation'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $bidang_usaha; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-4 col-xl-4">
    <div class="card flat-card">
        <div class="row-table">
            <div class="col-sm-3 card-body">
                <i class="feather icon-filter"></i>
            </div>
            <div class="col-sm-9">
                <h4><?php echo e($row->nama); ?></h4>
                <h6>UMKM : <?php echo e($row->umkm()->count()); ?></h6>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\vikor-umkm-rain\resources\views/dashboard/index.blade.php ENDPATH**/ ?>